import React, { useEffect, useState } from "react";
import {
  Plus, Search, Edit2, Trash2, Play, X, ChevronDown, ChevronRight,
  Copy, Settings, Upload, Clock, Layers, Repeat, Filter, Link2,
  FileText, ArrowUp, ArrowDown, Terminal, Globe, Shield,
  CheckCircle, XCircle, AlertCircle, AlertTriangle, GripVertical, MoreHorizontal,
  Save, RefreshCw, Database, AlignLeft, Code, Info, Zap,
  ToggleLeft, Eye, ChevronUp, Lock
} from "lucide-react";

// ─── Palette (matches App.tsx) ────────────────────────────────────────────────
const T = {
  primary:"#165DFF", success:"#00B42A", warning:"#FF7D00",
  danger:"#F53F3F",  purple:"#7816FF",  cyan:"#0891B2",
  border:"#E5E6EB",  bg:"#F4F6FA",
  t1:"#1D2129", t2:"#4E5969", t3:"#86909C", t4:"#C9CDD4",
};

// ─── Types ────────────────────────────────────────────────────────────────────
type StepType = "custom"|"ref-api"|"ref-case"|"ref-scene"|"loop"|"condition"|"once"|"script"|"wait";
type Method   = "GET"|"POST"|"PUT"|"DELETE"|"PATCH";
type Priority = "P0"|"P1"|"P2"|"P3";

interface Step {
  id: string; type: StepType; name: string;
  method?: Method; path?: string;
  enabled: boolean; depth: number;
  children?: Step[];
  timeoutMs?: number; connectTimeoutMs?: number; followRedirects?: boolean;
  paramsText?: string; headersText?: string; cookiesText?: string;
  bodyText?: string; authText?: string; schemaText?: string;
  preProcessorsText?: string; postProcessorsText?: string; requestAssertionsText?: string;
  script?: string; assertions?: string;
  assertionType?: "VARIABLE"|"SCRIPT";
  assertionTarget?: string; assertionOperator?: string; assertionExpected?: string; assertionScript?: string;
  delayMs?: number;
  loopType?: "FIXED"|"WHILE"|"FOREACH";
  loopCount?: number; foreachExpression?: string;
  conditionType?: "EXPRESSION"|"SCRIPT";
  conditionExpression?: string;
}
interface Scene {
  id: string; name: string; module: string; priority: Priority;
  status: "active"|"inactive"; desc: string; tags: string[];
  env: string; testData: string|null; iterations: number; threads: number;
  runLocation: "server"|"runner"; runnerId?: string; variableSet: string|null;
  steps: Step[]; lastRun: string|null; lastResult: "pass"|"fail"|null;
}
type SuiteItemType = "api"|"scene";
interface SuiteItem {
  id: string; type: SuiteItemType; name: string;
  method?: Method; path?: string; desc?: string;
}
interface Suite {
  id: string; name: string; module: string; priority: Priority;
  status: "ACTIVE"|"INACTIVE"; desc: string;
  items: SuiteItem[]; env: string; runMode: "serial"|"parallel";
  runLocation: "server"|"runner"; notify: boolean;
  lastRun: string|null; lastResult: "pass"|"fail"|null;
}
interface RunRecord {
  id: string; startTime: string; env: string;
  pass: number; total: number; fail: number;
  duration: string; operator: string; status: "pass"|"fail"|"running";
}

// ─── Step type config ─────────────────────────────────────────────────────────
const STEP_CFG: Record<StepType,{label:string;color:string;bg:string;icon:React.ElementType;desc:string}> = {
  custom:    {label:"自定义请求",color:T.primary,bg:"#E8F3FF",icon:Globe,  desc:"配置自定义 HTTP 请求"},
  "ref-api": {label:"引用接口",color:T.purple, bg:"#F5E8FF",icon:Link2,    desc:"选择已有接口，可引用或复制"},
  "ref-case":{label:"引用接口用例",color:T.cyan,bg:"#E0F7FA",icon:FileText,desc:"复用已有用例的请求与断言"},
  "ref-scene":{label:"引用场景",color:T.success,bg:"#E8FFEA",icon:Layers,  desc:"选择并复用已有测试场景"},
  loop:      {label:"循环",    color:"#4E5AC8",bg:"#EEEEFF",icon:Repeat,   desc:"循环执行子步骤"},
  condition: {label:"条件",    color:"#E91E8C",bg:"#FFE8F5",icon:Filter,   desc:"按条件分支执行"},
  once:      {label:"仅一次",  color:"#6B7280",bg:"#F2F3F5",icon:Shield,   desc:"整个场景只执行一次"},
  script:    {label:"脚本",    color:"#F59E0B",bg:"#FFFBEB",icon:Terminal, desc:"执行 JavaScript 脚本"},
  wait:      {label:"等待",    color:"#64748B",bg:"#F8FAFC",icon:Clock,    desc:"等待指定时间 (ms)"},
};
const METHOD_STYLE: Record<Method,{color:string;bg:string}> = {
  GET:    {color:T.success, bg:"#E8FFEA"},
  POST:   {color:T.primary, bg:"#E8F3FF"},
  PUT:    {color:T.warning, bg:"#FFF3E8"},
  DELETE: {color:T.danger,  bg:"#FFEEEE"},
  PATCH:  {color:T.purple,  bg:"#F5E8FF"},
};
const PRIORITY_STYLE: Record<Priority,{color:string;bg:string}> = {
  P0:{color:"#F53F3F",bg:"#FFEEEE"},
  P1:{color:"#FF7D00",bg:"#FFF3E8"},
  P2:{color:T.primary,bg:"#E8F3FF"},
  P3:{color:T.t3,     bg:"#F2F3F5"},
};

// ─── Mock data ────────────────────────────────────────────────────────────────
const INIT_SCENES: Scene[] = [
  {
    id:"s1", name:"产品管理-新增编辑删除闭环", module:"获客中心", priority:"P1",
    status:"active", desc:"由 Codex 根据获客中心低风险新增编辑删除接口生成的可重复闭环场景。",
    tags:["获客中心","CRUD闭环","Codex生成"], env:"测试环境", testData:null,
    iterations:1, threads:1, runLocation:"server", variableSet:null,
    lastRun:"2026-07-14 09:30", lastResult:"pass",
    steps:[
      {id:"st1",type:"ref-scene",name:"登录",enabled:true,depth:0},
      {id:"st2",type:"script",name:"生成本次测试数据",enabled:true,depth:0},
      {id:"st3",type:"custom",name:"新增产品",method:"POST",path:"/api/products",enabled:true,depth:0},
      {id:"st4",type:"custom",name:"查询新增产品并提取ID",method:"GET",path:"/api/products",enabled:true,depth:0},
      {id:"st5",type:"custom",name:"编辑产品",method:"PUT",path:"/api/products/{id}",enabled:true,depth:0},
      {id:"st6",type:"custom",name:"查询验证产品已编辑",method:"GET",path:"/api/products/{id}",enabled:true,depth:0},
      {id:"st7",type:"custom",name:"停用产品",method:"POST",path:"/api/products/{id}/disable",enabled:true,depth:0},
      {id:"st8",type:"custom",name:"查询验证产品已停用",method:"GET",path:"/api/products/{id}",enabled:true,depth:0},
      {id:"st9",type:"custom",name:"删除产品",method:"DELETE",path:"/api/products/{id}",enabled:true,depth:0},
      {id:"st10",type:"custom",name:"查询验证产品已删除",method:"GET",path:"/api/products/{id}",enabled:true,depth:0},
    ],
  },
  {
    id:"s2", name:"用户注册登录完整流程", module:"用户中心", priority:"P0",
    status:"active", desc:"覆盖注册→验证码→登录→Token刷新完整链路。",
    tags:["用户中心","核心链路"], env:"测试环境", testData:"注册测试数据集",
    iterations:3, threads:2, runLocation:"server", variableSet:"公共变量集",
    lastRun:"2026-07-13 22:00", lastResult:"fail",
    steps:[
      {id:"st11",type:"custom",name:"发送验证码",method:"POST",path:"/auth/sms/send",enabled:true,depth:0},
      {id:"st12",type:"wait",name:"等待短信到达 1500ms",enabled:true,depth:0},
      {id:"st13",type:"custom",name:"注册账户",method:"POST",path:"/auth/register",enabled:true,depth:0},
      {id:"st14",type:"custom",name:"登录获取Token",method:"POST",path:"/auth/login",enabled:true,depth:0},
      {id:"st15",type:"script",name:"提取并存储Token",enabled:true,depth:0},
      {id:"st16",type:"custom",name:"刷新Token",method:"POST",path:"/auth/refresh",enabled:true,depth:0},
    ],
  },
  {
    id:"s3", name:"订单全链路压测场景", module:"订单中心", priority:"P0",
    status:"active", desc:"从创建订单到支付到履约的完整业务链路。",
    tags:["订单","压测","主链路"], env:"预发布环境", testData:"订单压测数据集",
    iterations:50, threads:10, runLocation:"runner", runnerId:"runner-001",
    variableSet:"订单变量集", lastRun:"2026-07-12 03:00", lastResult:"pass",
    steps:[
      {id:"st17",type:"custom",name:"创建购物车",method:"POST",path:"/cart/create",enabled:true,depth:0},
      {id:"st18",type:"loop",name:"批量加入商品 (循环3次)",enabled:true,depth:0,
        children:[
          {id:"st18a",type:"custom",name:"加入商品",method:"POST",path:"/cart/items",enabled:true,depth:1},
        ]},
      {id:"st19",type:"custom",name:"下单",method:"POST",path:"/orders",enabled:true,depth:0},
      {id:"st20",type:"custom",name:"支付",method:"POST",path:"/orders/{id}/pay",enabled:true,depth:0},
      {id:"st21",type:"condition",name:"判断支付状态",enabled:true,depth:0,
        children:[
          {id:"st21a",type:"custom",name:"查询履约进度",method:"GET",path:"/fulfillment/{id}",enabled:true,depth:1},
        ]},
    ],
  },
  {
    id:"s4", name:"权限校验场景", module:"权限中心", priority:"P2",
    status:"inactive", desc:"验证各角色对敏感接口的权限边界。",
    tags:["权限","安全"], env:"测试环境", testData:null,
    iterations:1, threads:1, runLocation:"server", variableSet:null,
    lastRun:null, lastResult:null,
    steps:[
      {id:"st22",type:"ref-scene",name:"管理员登录",enabled:true,depth:0},
      {id:"st23",type:"custom",name:"访问管理员接口",method:"GET",path:"/admin/users",enabled:true,depth:0},
      {id:"st24",type:"ref-scene",name:"普通用户登录",enabled:true,depth:0},
      {id:"st25",type:"custom",name:"访问管理员接口（期望403）",method:"GET",path:"/admin/users",enabled:true,depth:0},
    ],
  },
];

const INIT_SUITES: Suite[] = [
  {
    id:"su1", name:"核心业务回归套件", module:"全部", priority:"P0",
    status:"ACTIVE", desc:"每次发版前必跑，覆盖用户、产品、订单核心链路",
    env:"测试环境", runMode:"serial", runLocation:"server", notify:true,
    lastRun:"2026-07-14 08:00", lastResult:"pass",
    items:[
      {id:"i1",type:"api",name:"用户注册",method:"POST",path:"/auth/register"},
      {id:"i2",type:"api",name:"用户登录",method:"POST",path:"/auth/login"},
      {id:"i3",type:"scene",name:"产品管理-新增编辑删除闭环",desc:"10个步骤"},
      {id:"i4",type:"scene",name:"订单全链路压测场景",desc:"5个步骤，循环嵌套"},
      {id:"i5",type:"api",name:"获取订单列表",method:"GET",path:"/orders"},
    ],
  },
  {
    id:"su2", name:"权限安全回归套件", module:"权限中心", priority:"P1",
    status:"ACTIVE", desc:"验证各角色权限边界，安全合规必跑",
    env:"测试环境", runMode:"parallel", runLocation:"runner", notify:false,
    lastRun:"2026-07-13 20:00", lastResult:"fail",
    items:[
      {id:"i6",type:"scene",name:"权限校验场景",desc:"4个步骤"},
      {id:"i7",type:"api",name:"查询用户权限",method:"GET",path:"/permissions"},
    ],
  },
  {
    id:"su3", name:"P0 接口冒烟套件", module:"全部", priority:"P0",
    status:"ACTIVE", desc:"上线前快速冒烟，核心接口可用性验证",
    env:"预发布环境", runMode:"parallel", runLocation:"server", notify:true,
    lastRun:"2026-07-14 07:30", lastResult:"pass",
    items:[
      {id:"i8",type:"api",name:"健康检查",method:"GET",path:"/health"},
      {id:"i9",type:"api",name:"获取配置",method:"GET",path:"/config"},
      {id:"i10",type:"api",name:"用户登录",method:"POST",path:"/auth/login"},
    ],
  },
];

const MOCK_RUN_RECORDS: RunRecord[] = [
  {id:"r1",startTime:"2026-07-14 08:00:12",env:"测试环境",pass:18,total:20,fail:2,duration:"2m 34s",operator:"张程远",status:"fail"},
  {id:"r2",startTime:"2026-07-13 20:01:05",env:"测试环境",pass:20,total:20,fail:0,duration:"2m 01s",operator:"自动调度",status:"pass"},
  {id:"r3",startTime:"2026-07-13 12:00:00",env:"测试环境",pass:19,total:20,fail:1,duration:"2m 18s",operator:"李雷",status:"fail"},
  {id:"r4",startTime:"2026-07-12 08:00:10",env:"预发布环境",pass:20,total:20,fail:0,duration:"1m 58s",operator:"自动调度",status:"pass"},
];

type SceneRunStatus = "pass"|"fail"|"running"|"cancelled";
type TriggerType = "manual"|"scheduled"|"ci";
interface SceneRunHistory {
  id: string; runAt: string; duration: string;
  stepsPass: number; stepsTotal: number; status: SceneRunStatus;
  trigger: TriggerType; operator: string; env: string;
}
const MOCK_SCENE_HISTORY: SceneRunHistory[] = [
  {id:"sh1",runAt:"2026-10-10 14:23:07",duration:"5.7s",stepsPass:7,stepsTotal:8,status:"fail",trigger:"manual",operator:"张程远",env:"测试环境"},
  {id:"sh2",runAt:"2026-10-10 09:01:32",duration:"4.2s",stepsPass:8,stepsTotal:8,status:"pass",trigger:"scheduled",operator:"自动调度",env:"测试环境"},
  {id:"sh3",runAt:"2026-10-09 17:44:19",duration:"4.8s",stepsPass:8,stepsTotal:8,status:"pass",trigger:"ci",operator:"CI/CD",env:"测试环境"},
  {id:"sh4",runAt:"2026-10-09 11:30:05",duration:"6.1s",stepsPass:5,stepsTotal:8,status:"fail",trigger:"manual",operator:"李雷",env:"预发布环境"},
  {id:"sh5",runAt:"2026-10-08 20:00:00",duration:"4.1s",stepsPass:8,stepsTotal:8,status:"pass",trigger:"scheduled",operator:"自动调度",env:"测试环境"},
  {id:"sh6",runAt:"2026-10-08 15:12:44",duration:"3.9s",stepsPass:8,stepsTotal:8,status:"pass",trigger:"manual",operator:"张程远",env:"本地联调"},
  {id:"sh7",runAt:"2026-10-07 09:05:18",duration:"—",stepsPass:0,stepsTotal:8,status:"cancelled",trigger:"manual",operator:"张程远",env:"测试环境"},
];

const MOCK_CANDIDATE_CASES = [
  {id:"c001",name:"查询商品列表",method:"GET" as Method,path:"/products",api:"商品接口",inSuite:false},
  {id:"c002",name:"新增商品",method:"POST" as Method,path:"/products",api:"商品接口",inSuite:true},
  {id:"c003",name:"获取用户信息",method:"GET" as Method,path:"/users/{id}",api:"用户接口",inSuite:false},
  {id:"c004",name:"更新用户信息",method:"PUT" as Method,path:"/users/{id}",api:"用户接口",inSuite:false},
  {id:"c005",name:"删除订单",method:"DELETE" as Method,path:"/orders/{id}",api:"订单接口",inSuite:false},
  {id:"c006",name:"创建订单",method:"POST" as Method,path:"/orders",api:"订单接口",inSuite:false},
];

const MOCK_CANDIDATE_APIS = [
  {id:"api001",name:"查询商品列表",method:"GET" as Method,path:"/products",module:"商品中心"},
  {id:"api002",name:"新增商品",method:"POST" as Method,path:"/products",module:"商品中心"},
  {id:"api003",name:"获取用户信息",method:"GET" as Method,path:"/users/{id}",module:"用户中心"},
  {id:"api004",name:"创建订单",method:"POST" as Method,path:"/orders",module:"订单中心"},
  {id:"api005",name:"查询订单详情",method:"GET" as Method,path:"/orders/{id}",module:"订单中心"},
  {id:"api006",name:"发起支付",method:"POST" as Method,path:"/orders/{id}/pay",module:"支付中心"},
];

const MOCK_CANDIDATE_SCENES = [
  {id:"s1",name:"产品管理-新增编辑删除闭环",module:"获客中心",steps:10,status:"active",inSuite:true},
  {id:"s2",name:"用户注册登录完整流程",module:"用户中心",steps:6,status:"active",inSuite:false},
  {id:"s3",name:"订单全链路压测场景",module:"订单中心",steps:5,status:"active",inSuite:true},
  {id:"s4",name:"权限校验场景",module:"权限中心",steps:4,status:"inactive",inSuite:false},
];

const ENVS = ["测试环境","预发布环境","生产环境(只读)","本地联调"];
const MODULES = ["全部","获客中心","用户中心","订单中心","权限中心","结算中心"];
const VARIABLE_SETS = ["公共变量集","订单变量集","用户变量集"];
const RUNNERS = [{id:"runner-001",name:"Runner-主机A",status:"在线"},{id:"runner-002",name:"Runner-主机B",status:"离线"}];

// ─── Atoms ────────────────────────────────────────────────────────────────────
function Btn({children,onClick,small,color=T.primary,ghost,danger,icon:Icon,disabled}:{
  children?:React.ReactNode;onClick?:()=>void;small?:boolean;color?:string;ghost?:boolean;danger?:boolean;icon?:React.ElementType;disabled?:boolean}){
  if(ghost)return(
    <button disabled={disabled} onClick={onClick}
      className="inline-flex items-center gap-1.5 h-7 px-3 rounded-lg border text-[12px] font-medium bg-white transition-colors"
      style={{borderColor:T.border,color:danger?T.danger:T.t2,opacity:disabled?.5:1}}>
      {Icon&&<Icon size={12}/>}{children}
    </button>
  );
  return(
    <button disabled={disabled} onClick={onClick}
      className="inline-flex items-center gap-1.5 font-medium rounded-lg transition-all active:scale-[.98]"
      style={{backgroundColor:danger?T.danger:color,color:"#fff",height:small?26:32,padding:small?"0 10px":"0 14px",fontSize:small?11:13,opacity:disabled?.5:1}}>
      {Icon&&<Icon size={small?11:13}/>}{children}
    </button>
  );
}
function IBtn({icon:Icon,label,danger,onClick}:{icon:React.ElementType;label:string;danger?:boolean;onClick?:()=>void}){
  return(
    <button title={label} onClick={onClick}
      className="w-6 h-6 flex items-center justify-center rounded-md transition-colors hover:opacity-80"
      style={{color:danger?T.danger:T.t3}}
      onMouseEnter={e=>{e.currentTarget.style.backgroundColor=danger?"#FFEEEE":"#F2F3F5";}}
      onMouseLeave={e=>{e.currentTarget.style.backgroundColor="transparent";}}>
      <Icon size={13}/>
    </button>
  );
}
function Sel({value,onChange,options,width=120}:{value:string;onChange:(v:string)=>void;options:string[];width?:number}){
  return(
    <select value={value} onChange={e=>onChange(e.target.value)}
      className="h-7 px-2.5 border rounded-lg text-[12px] outline-none appearance-none bg-white"
      style={{borderColor:T.border,color:T.t1,width}}>
      {options.map(o=><option key={o}>{o}</option>)}
    </select>
  );
}
function Inp({value,onChange,placeholder,width=120}:{value?:string;onChange?:(v:string)=>void;placeholder?:string;width?:number|string}){
  return(
    <input value={value} onChange={e=>onChange?.(e.target.value)} placeholder={placeholder}
      className="h-7 px-2.5 border rounded-lg text-[12px] outline-none bg-white"
      style={{borderColor:T.border,color:T.t1,width}}/>
  );
}
function NumInp({value,onChange,min=1,max=999,width=56}:{value:number;onChange:(v:number)=>void;min?:number;max?:number;width?:number}){
  return(
    <input type="number" value={value} min={min} max={max}
      onChange={e=>onChange(Math.min(max,Math.max(min,Number(e.target.value))))}
      className="h-7 px-2 border rounded-lg text-[12px] text-center outline-none bg-white"
      style={{borderColor:T.border,color:T.t1,width}}/>
  );
}
function Toggle({on,onToggle}:{on:boolean;onToggle:()=>void}){
  return(
    <button onClick={onToggle} className="relative flex-shrink-0 rounded-full transition-colors"
      style={{width:28,height:16,backgroundColor:on?T.primary:T.t4}}>
      <span className="absolute top-[2px] rounded-full bg-white transition-all"
        style={{width:12,height:12,left:on?14:2}}/>
    </button>
  );
}
function StatusDot({status}:{status:"pass"|"fail"|"running"|null}){
  if(!status) return <span className="text-[11px]" style={{color:T.t4}}>未运行</span>;
  const cfg={pass:{color:T.success,label:"通过"},fail:{color:T.danger,label:"失败"},running:{color:T.primary,label:"运行中"}};
  const c=cfg[status];
  return(
    <span className="flex items-center gap-1.5 text-[12px] font-medium" style={{color:c.color}}>
      <span className="w-1.5 h-1.5 rounded-full" style={{backgroundColor:c.color}}/>
      {c.label}
    </span>
  );
}
function PTag({p}:{p:Priority}){
  const s=PRIORITY_STYLE[p];
  return<span className="px-1.5 py-0.5 rounded text-[11px] font-bold" style={{backgroundColor:s.bg,color:s.color}}>{p}</span>;
}
function MethodTag({m}:{m:Method}){
  const s=METHOD_STYLE[m];
  return<span className="w-14 text-center rounded text-[10px] font-bold py-0.5" style={{backgroundColor:s.bg,color:s.color}}>{m}</span>;
}
function StepBadge({type}:{type:StepType}){
  const c=STEP_CFG[type];
  return<span className="px-1.5 py-0.5 rounded text-[10px] font-bold flex-shrink-0" style={{backgroundColor:c.bg,color:c.color}}>{c.label}</span>;
}

// ─── Modal wrapper ────────────────────────────────────────────────────────────
function Modal({title,onClose,children,width=560}:{title:string;onClose:()=>void;children:React.ReactNode;width?:number}){
  return(
    <div className="fixed inset-0 z-50 flex items-center justify-center" style={{backgroundColor:"rgba(0,0,0,0.36)"}}>
      <div className="rounded-2xl shadow-2xl bg-white flex flex-col overflow-hidden" style={{width,maxHeight:"82vh"}}>
        <div className="flex items-center justify-between px-5 py-4 flex-shrink-0" style={{borderBottom:`1px solid ${T.border}`}}>
          <p className="font-semibold text-[15px]" style={{color:T.t1}}>{title}</p>
          <button onClick={onClose} className="w-7 h-7 flex items-center justify-center rounded-md hover:bg-gray-100">
            <X size={15} style={{color:T.t3}}/>
          </button>
        </div>
        <div className="flex-1 overflow-y-auto">{children}</div>
      </div>
    </div>
  );
}

// ─── Add Step Dialog ──────────────────────────────────────────────────────────
const ADD_STEP_TYPES:StepType[]=[
  "ref-api","ref-case","ref-scene",
  "custom","script","wait","loop","condition","once",
];

function createStepDraft(type:StepType,depth=0):Step{
  const base:Step={
    id:`st${Date.now()}_${Math.random().toString(36).slice(2,7)}`,
    type,
    name:STEP_CFG[type].label+(type==="custom"?"":"步骤"),
    enabled:true,
    depth,
  };
  if(type==="custom")return {...base,method:"POST",path:"",timeoutMs:30000,connectTimeoutMs:10000,followRedirects:true};
  if(type==="script")return {...base,script:"",assertionType:"VARIABLE",assertionTarget:"",assertionOperator:"等于",assertionExpected:"",assertionScript:""};
  if(type==="wait")return {...base,delayMs:1000};
  if(type==="loop")return {...base,loopType:"FIXED",loopCount:1,conditionExpression:"",foreachExpression:"",children:[]};
  if(type==="condition")return {...base,conditionType:"EXPRESSION",conditionExpression:"",children:[]};
  if(type==="once")return {...base,children:[]};
  return base;
}

function updateStepTree(steps:Step[],updated:Step):Step[]{
  return steps.map(step=>{
    if(step.id===updated.id)return updated;
    if(step.children?.length)return {...step,children:updateStepTree(step.children,updated)};
    return step;
  });
}

function AddStepDialog({onAdd,onSelectResource,onClose}:{
  onAdd:(type:StepType)=>void;
  onSelectResource:(type:"api"|"case"|"scene")=>void;
  onClose:()=>void;
}){
  const resourceType:Partial<Record<StepType,"api"|"case"|"scene">>={
    "ref-api":"api",
    "ref-case":"case",
    "ref-scene":"scene",
  };
  return(
    <Modal title="选择步骤类型" onClose={onClose} width={640}>
      <div className="p-5">
        <p className="text-[11px] font-semibold mb-2" style={{color:T.t4}}>复用已有资源</p>
        <div className="grid grid-cols-2 gap-3 mb-5">
        {ADD_STEP_TYPES.slice(0,3).map(type=>{
          const c=STEP_CFG[type];
          const Icon=c.icon;
          return(
            <button key={type} onClick={()=>{
              const resource=resourceType[type];
              if(resource)onSelectResource(resource);
              else onAdd(type);
              onClose();
            }}
              className="flex items-start gap-3 p-4 rounded-xl border text-left transition-all hover:shadow-md"
              style={{borderColor:T.border}}
              onMouseEnter={e=>{e.currentTarget.style.borderColor=c.color;e.currentTarget.style.backgroundColor=c.bg;}}
              onMouseLeave={e=>{e.currentTarget.style.borderColor=T.border;e.currentTarget.style.backgroundColor="transparent";}}>
              <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5" style={{backgroundColor:c.bg}}>
                <Icon size={16} color={c.color}/>
              </div>
              <div>
                <p className="text-[13px] font-semibold" style={{color:T.t1}}>{c.label}</p>
                <p className="text-[12px] mt-0.5" style={{color:T.t3}}>{c.desc}</p>
              </div>
            </button>
          );
        })}
        </div>
        <p className="text-[11px] font-semibold mb-2" style={{color:T.t4}}>新建步骤</p>
        <div className="grid grid-cols-2 gap-3">
        {ADD_STEP_TYPES.slice(3).map(type=>{
          const c=STEP_CFG[type];
          const Icon=c.icon;
          return(
            <button key={type} onClick={()=>{onAdd(type);onClose();}}
              className="flex items-start gap-3 p-4 rounded-xl border text-left transition-all hover:shadow-md"
              style={{borderColor:T.border}}
              onMouseEnter={e=>{e.currentTarget.style.borderColor=c.color;e.currentTarget.style.backgroundColor=c.bg;}}
              onMouseLeave={e=>{e.currentTarget.style.borderColor=T.border;e.currentTarget.style.backgroundColor="transparent";}}>
              <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5" style={{backgroundColor:c.bg}}>
                <Icon size={16} color={c.color}/>
              </div>
              <div>
                <p className="text-[13px] font-semibold" style={{color:T.t1}}>{c.label}</p>
                <p className="text-[12px] mt-0.5" style={{color:T.t3}}>{c.desc}</p>
              </div>
            </button>
          );
        })}
        </div>
      </div>
    </Modal>
  );
}

// ─── Resource Picker Dialog ───────────────────────────────────────────────────
function ResourcePickerDialog({resourceType,currentSceneId,onClose}:{
  resourceType:"api"|"case"|"scene";
  currentSceneId:string;
  onClose:(steps:Step[])=>void;
}){
  const[search,setSearch]=useState("");
  const[selected,setSelected]=useState<Set<string>>(new Set());
  const[importMode,setImportMode]=useState<"ref"|"copy">("ref");
  const[loading,setLoading]=useState(true);
  useEffect(()=>{
    const timer=setTimeout(()=>setLoading(false),450);
    return()=>clearTimeout(timer);
  },[]);
  const dialogTitle={
    api:"选择接口",
    case:"选择接口用例",
    scene:"选择场景",
  }[resourceType];
  const searchPlaceholder={
    api:"搜索接口名称 / 路径",
    case:"搜索用例名称 / 路径",
    scene:"搜索场景名称 / 模块",
  }[resourceType];

  const buildSteps=():Step[]=>{
    const now=Date.now();
    if(resourceType==="api"){
      return MOCK_CANDIDATE_APIS.filter(api=>selected.has(api.id)).map((api,i)=>({
        id:`st${now}_${i}`,
        type:(importMode==="ref"?"ref-api":"custom") as StepType,
        name:api.name, method:api.method, path:api.path,
        enabled:true, depth:0,
      }));
    }
    if(resourceType==="case"){
      return MOCK_CANDIDATE_CASES.filter(c=>selected.has(c.id)).map((c,i)=>({
        id:`st${now}_${i}`,
        type:(importMode==="ref"?"ref-case":"custom") as StepType,
        name:c.name, method:c.method, path:c.path,
        enabled:true, depth:0,
      }));
    }
    if(resourceType==="scene"){
      const scenes=MOCK_CANDIDATE_SCENES.filter(s=>selected.has(s.id));
      return scenes.map((s,i)=>({
        id:`st${now}_${i}`,
        type:"ref-scene" as StepType,
        name:s.name, enabled:true, depth:0,
      }));
    }
    return [];
  };

  const apiRows=MOCK_CANDIDATE_APIS.filter(api=>
    !search||api.name.toLowerCase().includes(search.toLowerCase())||api.path.toLowerCase().includes(search.toLowerCase())
  );
  const caseRows=MOCK_CANDIDATE_CASES.filter(c=>
    !search||c.name.toLowerCase().includes(search.toLowerCase())||c.path.toLowerCase().includes(search.toLowerCase())
  );
  const sceneRows=MOCK_CANDIDATE_SCENES.filter(s=>
    !search||s.name.toLowerCase().includes(search.toLowerCase())||s.module.toLowerCase().includes(search.toLowerCase())
  );
  const visibleIds=resourceType==="api"
    ? apiRows.map(row=>row.id)
    : resourceType==="case"
      ? caseRows.map(row=>row.id)
      : sceneRows.filter(row=>row.id!==currentSceneId).map(row=>row.id);
  const allSelected=visibleIds.length>0&&visibleIds.every(id=>selected.has(id));
  const someSelected=visibleIds.some(id=>selected.has(id));

  const toggle=(id:string)=>{
    const n=new Set(selected);
    if(n.has(id))n.delete(id);else n.add(id);
    setSelected(n);
  };
  const toggleAll=()=>{
    const next=new Set(selected);
    if(allSelected)visibleIds.forEach(id=>next.delete(id));
    else visibleIds.forEach(id=>next.add(id));
    setSelected(next);
  };
  const SelectAll=()=>(
    <input
      type="checkbox"
      checked={allSelected}
      ref={el=>{if(el)el.indeterminate=someSelected&&!allSelected;}}
      onChange={toggleAll}
      className="rounded"
      aria-label="全选当前列表"
    />
  );
  const modeHint=importMode==="ref"
    ? resourceType==="scene"
      ? "引用后将嵌套执行所选场景，并跟随源场景更新。"
      : "引用后保留与源资源的关联，并跟随源资源更新。"
    : resourceType==="scene"
      ? "复制场景步骤尚待后端接入，当前请使用引用方式。"
      : "复制后生成独立步骤，后续修改不会影响源资源。";

  return(
    <Modal title={dialogTitle} onClose={()=>onClose([])} width={720}>
      <div className="flex flex-col" style={{height:500}}>
        {/* Workspace + search */}
        <div className="flex items-center justify-end px-4 py-2.5 flex-shrink-0" style={{borderBottom:`1px solid ${T.border}`,backgroundColor:"#FAFBFE"}}>
          <div className="flex items-center gap-2">
            <Sel value="X-MAN" onChange={()=>{}} options={["X-MAN","全部工作区"]} width={120}/>
            <div className="relative">
              <input value={search} onChange={e=>setSearch(e.target.value)} placeholder={searchPlaceholder}
                className="h-7 pl-7 pr-3 border rounded-lg text-[12px] outline-none"
                style={{borderColor:T.border,color:T.t1,width:210}}/>
              <Search size={12} className="absolute left-2 top-1/2 -translate-y-1/2" style={{color:T.t3}}/>
            </div>
          </div>
        </div>
        {/* Table */}
        <div className="flex-1 overflow-y-auto">
          {loading
            ? <div className="h-full flex flex-col items-center justify-center" style={{color:T.t3}}>
                <RefreshCw size={20} className="animate-spin mb-2"/>
                <p className="text-[12px]">正在加载资源…</p>
              </div>
            : <>
          {resourceType==="case"&&(
            <table className="w-full text-[12px]">
              <thead>
                <tr style={{backgroundColor:T.bg,borderBottom:`1px solid ${T.border}`}}>
                  <th className="px-4 py-2 text-left w-8"><SelectAll/></th>
                  <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>ID</th>
                  <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>用例名称</th>
                  <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>方法</th>
                  <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>请求路径</th>
                  <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>所属接口</th>
                </tr>
              </thead>
              <tbody>
                {caseRows.length===0&&(
                  <tr><td colSpan={6}>
                    <div className="flex flex-col items-center justify-center py-16" style={{color:T.t4}}>
                      <Search size={26} style={{opacity:.35,marginBottom:8}}/>
                      <p className="text-[13px]" style={{color:T.t3}}>未找到匹配的接口用例</p>
                      <p className="text-[11px] mt-1">请调整关键词或工作区筛选条件</p>
                    </div>
                  </td></tr>
                )}
                {caseRows.map((c,i)=>(
                  <tr key={c.id} style={{borderBottom:`1px solid ${T.border}`,backgroundColor:i%2===0?"transparent":T.bg+"80"}}>
                    <td className="px-4 py-2.5">
                      <input type="checkbox" checked={selected.has(c.id)} onChange={()=>toggle(c.id)} className="rounded"/>
                    </td>
                    <td className="px-2 py-2.5 font-mono" style={{color:T.t3}}>{c.id}</td>
                    <td className="px-2 py-2.5 font-medium" style={{color:T.t1}}>{c.name}</td>
                    <td className="px-2 py-2.5"><MethodTag m={c.method}/></td>
                    <td className="px-2 py-2.5 font-mono" style={{color:T.t2}}>{c.path}</td>
                    <td className="px-2 py-2.5" style={{color:T.t3}}>{c.api}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          {resourceType==="scene"&&(
            <table className="w-full text-[12px]">
              <thead>
                <tr style={{backgroundColor:T.bg,borderBottom:`1px solid ${T.border}`}}>
                  <th className="px-4 py-2 text-left w-8"><SelectAll/></th>
                  <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>ID</th>
                  <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>场景名称</th>
                  <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>所属模块</th>
                  <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>步骤数</th>
                  <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>状态</th>
                </tr>
              </thead>
              <tbody>
                {sceneRows.length===0&&(
                  <tr><td colSpan={6}>
                    <div className="flex flex-col items-center justify-center py-16" style={{color:T.t4}}>
                      <Search size={26} style={{opacity:.35,marginBottom:8}}/>
                      <p className="text-[13px]" style={{color:T.t3}}>未找到匹配的场景</p>
                      <p className="text-[11px] mt-1">请调整关键词或工作区筛选条件</p>
                    </div>
                  </td></tr>
                )}
                {sceneRows.map((s,i)=>(
                  <tr key={s.id} style={{borderBottom:`1px solid ${T.border}`,backgroundColor:i%2===0?"transparent":T.bg+"80",opacity:s.id===currentSceneId?.55:1}}>
                    <td className="px-4 py-2.5">
                      {s.id===currentSceneId
                        ? <span className="text-[10px] px-1.5 py-0.5 rounded whitespace-nowrap" style={{backgroundColor:"#F2F3F5",color:T.t3}}>当前场景</span>
                        : <input type="checkbox" checked={selected.has(s.id)} onChange={()=>toggle(s.id)} className="rounded"/>
                      }
                    </td>
                    <td className="px-2 py-2.5 font-mono" style={{color:T.t3}}>{s.id}</td>
                    <td className="px-2 py-2.5 font-medium" style={{color:T.t1}}>{s.name}</td>
                    <td className="px-2 py-2.5" style={{color:T.t3}}>{s.module}</td>
                    <td className="px-2 py-2.5" style={{color:T.t2}}>{s.steps} 个</td>
                    <td className="px-2 py-2.5"><StatusDot status={s.status==="active"?"pass":null}/></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          {resourceType==="api"&&(
            <table className="w-full text-[12px]">
              <thead>
                <tr style={{backgroundColor:T.bg,borderBottom:`1px solid ${T.border}`}}>
                  <th className="px-4 py-2 text-left w-8"><SelectAll/></th>
                  <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>ID</th>
                  <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>接口名称</th>
                  <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>方法</th>
                  <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>请求路径</th>
                  <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>所属模块</th>
                </tr>
              </thead>
              <tbody>
                {apiRows.length===0&&(
                  <tr><td colSpan={6}>
                    <div className="flex flex-col items-center justify-center py-16" style={{color:T.t4}}>
                      <Search size={26} style={{opacity:.35,marginBottom:8}}/>
                      <p className="text-[13px]" style={{color:T.t3}}>未找到匹配的接口</p>
                      <p className="text-[11px] mt-1">请调整关键词或工作区筛选条件</p>
                    </div>
                  </td></tr>
                )}
                {apiRows.map((api,i)=>(
                  <tr key={api.id} style={{borderBottom:`1px solid ${T.border}`,backgroundColor:i%2===0?"transparent":T.bg+"80"}}>
                    <td className="px-4 py-2.5">
                      <input type="checkbox" checked={selected.has(api.id)} onChange={()=>toggle(api.id)} className="rounded"/>
                    </td>
                    <td className="px-2 py-2.5 font-mono" style={{color:T.t3}}>{api.id}</td>
                    <td className="px-2 py-2.5 font-medium" style={{color:T.t1}}>{api.name}</td>
                    <td className="px-2 py-2.5"><MethodTag m={api.method}/></td>
                    <td className="px-2 py-2.5 font-mono" style={{color:T.t2}}>{api.path}</td>
                    <td className="px-2 py-2.5" style={{color:T.t3}}>{api.module}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          </>}
        </div>
        {/* Footer */}
        <div className="flex items-end justify-between gap-4 px-4 py-3 flex-shrink-0" style={{borderTop:`1px solid ${T.border}`}}>
          <div>
            <p className="text-[12px]" style={{color:T.t3}}>
              已选择 <strong style={{color:T.primary}}>{selected.size}</strong> 项
            </p>
            <p className="text-[11px] mt-1" style={{color:T.t4}}>{modeHint}</p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[12px]" style={{color:T.t3}}>添加方式：</span>
            {(["ref","copy"] as const).map(m=>(
              <button key={m} onClick={()=>!(resourceType==="scene"&&m==="copy")&&setImportMode(m)}
                disabled={resourceType==="scene"&&m==="copy"}
                className="h-6 px-2.5 rounded text-[11px] font-medium border transition-colors"
                style={{borderColor:m===importMode?T.primary:T.border,
                  backgroundColor:m===importMode?"#E8F3FF":"transparent",
                  color:m===importMode?T.primary:T.t2,
                  opacity:resourceType==="scene"&&m==="copy"?0.5:1,
                  cursor:resourceType==="scene"&&m==="copy"?"not-allowed":"pointer"}}>
                {m==="ref"?"引用":resourceType==="scene"?"复制步骤（待接入）":"复制"}
              </button>
            ))}
            <div className="w-px h-4 mx-1" style={{backgroundColor:T.border}}/>
            <Btn ghost onClick={()=>onClose([])}>取消</Btn>
            <Btn onClick={()=>onClose(buildSteps())} disabled={selected.size===0}>
              添加 {selected.size>0?`(${selected.size})`:""}
            </Btn>
          </div>
        </div>
      </div>
    </Modal>
  );
}

// ─── Custom Request Panel ─────────────────────────────────────────────────────
function CustomRequestPanel({step,onClose}:{step:Step;onClose:()=>void}){
  const[method,setMethod]=useState<Method>(step.method||"POST");
  const[url,setUrl]=useState(step.path||"");
  const[tab,setTab]=useState("params");
  const[ran,setRan]=useState(false);
  const methods:Method[]=["GET","POST","PUT","DELETE","PATCH"];
  const configTabs=[
    {k:"params",l:"Params"},{k:"headers",l:"Headers"},{k:"body",l:"Body"},
    {k:"auth",l:"Auth"},{k:"pre",l:"前置处理"},{k:"post",l:"后置处理"},
    {k:"assert",l:"断言"},{k:"settings",l:"设置"},
  ];
  return(
    <div className="fixed inset-0 z-50 flex items-end justify-end" style={{backgroundColor:"rgba(0,0,0,.3)"}}>
      <div className="flex flex-col bg-white shadow-2xl" style={{width:680,height:"100vh",borderLeft:`1px solid ${T.border}`}}>
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 flex-shrink-0" style={{borderBottom:`1px solid ${T.border}`}}>
          <p className="font-semibold text-[14px]" style={{color:T.t1}}>配置步骤 · {step.name}</p>
          <button onClick={onClose} className="w-7 h-7 flex items-center justify-center rounded-md hover:bg-gray-100">
            <X size={15} style={{color:T.t3}}/>
          </button>
        </div>
        {/* URL bar */}
        <div className="flex items-center gap-2 px-4 py-3 flex-shrink-0" style={{borderBottom:`1px solid ${T.border}`}}>
          <select value={method} onChange={e=>setMethod(e.target.value as Method)}
            className="h-8 px-2 border rounded-lg text-[12px] font-bold outline-none"
            style={{borderColor:METHOD_STYLE[method].color,color:METHOD_STYLE[method].color,backgroundColor:METHOD_STYLE[method].bg,width:88}}>
            {methods.map(m=><option key={m}>{m}</option>)}
          </select>
          <input value={url} onChange={e=>setUrl(e.target.value)} placeholder="请输入请求 URL"
            className="flex-1 h-8 px-3 border rounded-lg text-[12px] outline-none font-mono"
            style={{borderColor:T.border,color:T.t1}}/>
          <button onClick={()=>setRan(true)}
            className="h-8 px-4 rounded-lg text-[12px] font-medium text-white flex items-center gap-1.5"
            style={{backgroundColor:T.success}}>
            <Zap size={12}/>调试
          </button>
        </div>
        {/* Tabs */}
        <div className="flex gap-0 flex-shrink-0 px-4" style={{borderBottom:`1px solid ${T.border}`}}>
          {configTabs.map(({k,l})=>(
            <button key={k} onClick={()=>setTab(k)}
              className="px-3 py-2 text-[12px] font-medium border-b-2 transition-colors"
              style={{borderBottomColor:tab===k?T.primary:"transparent",color:tab===k?T.primary:T.t3}}>
              {l}
            </button>
          ))}
        </div>
        {/* Tab content */}
        <div className="flex-1 overflow-y-auto p-4">
          {tab==="params"&&(
            <div>
              <table className="w-full text-[12px] mb-3">
                <thead><tr style={{color:T.t3}}>
                  <th className="text-left py-1 w-8"/>
                  <th className="text-left py-1 w-1/3">参数名</th>
                  <th className="text-left py-1">参数值</th>
                  <th className="text-left py-1 w-8"/>
                </tr></thead>
                <tbody>
                  {[{k:"pageSize",v:"20"},{k:"pageNum",v:"1"}].map((r,i)=>(
                    <tr key={i}>
                      <td className="py-1"><input type="checkbox" defaultChecked className="rounded"/></td>
                      <td className="py-1 pr-2"><input defaultValue={r.k} className="w-full h-7 px-2 border rounded text-[12px] outline-none" style={{borderColor:T.border}}/></td>
                      <td className="py-1 pr-2"><input defaultValue={r.v} className="w-full h-7 px-2 border rounded text-[12px] outline-none" style={{borderColor:T.border}}/></td>
                      <td className="py-1"><IBtn icon={Trash2} label="删除" danger/></td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <button className="text-[12px] flex items-center gap-1" style={{color:T.primary}}>
                <Plus size={12}/>添加参数
              </button>
            </div>
          )}
          {tab==="body"&&(
            <div>
              <div className="flex gap-3 mb-3">
                {["none","json","form-data","x-www-form-urlencoded","raw"].map(m=>(
                  <label key={m} className="flex items-center gap-1 text-[12px] cursor-pointer" style={{color:T.t2}}>
                    <input type="radio" name="bodyType" defaultChecked={m==="json"} className="accent-blue-600"/>{m}
                  </label>
                ))}
              </div>
              <textarea defaultValue={'{\n  "name": "测试产品",\n  "price": 99.9,\n  "category": "{{category}}"\n}'}
                className="w-full border rounded-lg p-3 text-[12px] font-mono outline-none resize-none"
                style={{height:200,borderColor:T.border,color:T.t1,backgroundColor:"#FAFAFA"}}/>
            </div>
          )}
          {tab==="assert"&&(
            <div className="space-y-3">
              <div className="p-3 rounded-xl border" style={{borderColor:T.border}}>
                <div className="flex items-center justify-between mb-2">
                  <p className="text-[12px] font-semibold" style={{color:T.t1}}>断言规则</p>
                  <Btn small ghost icon={Plus}>添加断言</Btn>
                </div>
                {[
                  {type:"状态码",op:"等于",val:"200"},
                  {type:"响应体",op:"JSON路径",val:"$.data.id 不为空"},
                ].map((a,i)=>(
                  <div key={i} className="flex items-center gap-2 py-2" style={{borderTop:`1px solid ${T.border}`}}>
                    <select className="h-6 px-2 border rounded text-[11px] outline-none" style={{borderColor:T.border}}><option>{a.type}</option></select>
                    <select className="h-6 px-2 border rounded text-[11px] outline-none" style={{borderColor:T.border}}><option>{a.op}</option></select>
                    <input defaultValue={a.val} className="flex-1 h-6 px-2 border rounded text-[11px] outline-none" style={{borderColor:T.border}}/>
                    <IBtn icon={Trash2} label="删除" danger/>
                  </div>
                ))}
              </div>
            </div>
          )}
          {(tab==="pre"||tab==="post")&&(
            <div className="space-y-2">
              {[{type:"脚本",desc:"JavaScript 前置脚本"}].map((item,i)=>(
                <div key={i} className="p-3 rounded-xl border" style={{borderColor:T.border}}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[12px] font-medium" style={{color:T.t1}}>{item.type}</span>
                    <IBtn icon={Trash2} label="删除" danger/>
                  </div>
                  <textarea defaultValue="// pm.variables.set('token', pm.response.json().data.token);"
                    className="w-full border rounded p-2 text-[11px] font-mono outline-none resize-none"
                    style={{height:80,borderColor:T.border,backgroundColor:"#FAFAFA"}}/>
                </div>
              ))}
              <button className="text-[12px] flex items-center gap-1" style={{color:T.primary}}>
                <Plus size={12}/>添加{tab==="pre"?"前置":"后置"}处理
              </button>
            </div>
          )}
          {(tab==="headers"||tab==="auth"||tab==="settings")&&(
            <div className="flex items-center justify-center py-12" style={{color:T.t3}}>
              <p className="text-[12px]">{tab==="settings"?"步骤超时、重试等配置":"请配置相应参数"}</p>
            </div>
          )}
        </div>
        {/* Response panel */}
        {ran&&(
          <div className="flex-shrink-0" style={{borderTop:`1px solid ${T.border}`,height:220}}>
            <div className="flex items-center gap-3 px-4 py-2 flex-shrink-0" style={{borderBottom:`1px solid ${T.border}`}}>
              <span className="text-[11px] font-bold px-2 py-0.5 rounded" style={{backgroundColor:"#E8FFEA",color:T.success}}>200 OK</span>
              <span className="text-[11px]" style={{color:T.t3}}>342 ms · 1.2 KB</span>
              <div className="flex-1"/>
              {["Body","响应头","断言结果","控制台"].map(t=>(
                <button key={t} className="text-[11px] px-2 py-0.5 rounded hover:bg-gray-100" style={{color:T.t2}}>{t}</button>
              ))}
            </div>
            <pre className="p-4 text-[11px] font-mono overflow-auto" style={{height:176,color:T.t1}}>
{`{
  "code": 0,
  "data": {
    "id": "prod_20240714_001",
    "name": "测试产品",
    "status": "active"
  },
  "message": "success"
}`}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Unified Step Config Drawer ───────────────────────────────────────────────
function StepConfigDrawer({step,isNew,currentSceneId,onSave,onClose}:{
  step:Step;isNew:boolean;currentSceneId:string;onSave:(step:Step)=>void;onClose:()=>void;
}){
  const[draft,setDraft]=useState<Step>({...step,children:step.children?.map(child=>({...child}))});
  const[requestTab,setRequestTab]=useState("Params");
  const[debugSent,setDebugSent]=useState(false);
  const[saveState,setSaveState]=useState<"idle"|"saving">("idle");
  const[error,setError]=useState("");
  const[confirmClose,setConfirmClose]=useState(false);
  const[childPicker,setChildPicker]=useState(false);
  const[childResourcePicker,setChildResourcePicker]=useState<"api"|"case"|"scene"|null>(null);
  const[editingChild,setEditingChild]=useState<{step:Step;index:number|null}|null>(null);
  const initial=JSON.stringify(step);
  const dirty=isNew||JSON.stringify(draft)!==initial;
  const isControl=draft.type==="loop"||draft.type==="condition"||draft.type==="once";
  const maxDepthReached=draft.depth>=2;

  const set=<K extends keyof Step>(key:K,value:Step[K])=>setDraft(prev=>({...prev,[key]:value}));
  const validate=()=>{
    if(!draft.name.trim())return "请输入步骤名称";
    if(draft.type==="custom"&&!draft.path?.trim())return "请输入请求路径";
    if(draft.type==="script"&&!draft.script?.trim())return "脚本内容不能为空";
    if(draft.type==="wait"&&((draft.delayMs??0)<1||(draft.delayMs??0)>60000))return "等待时长必须在 1–60000ms 之间";
    if(draft.type==="loop"){
      if(draft.loopType==="FIXED"&&((draft.loopCount??0)<0||(draft.loopCount??0)>50))return "固定循环次数必须在 0–50 之间";
      if(draft.loopType==="WHILE"&&!draft.conditionExpression?.trim())return "请输入 WHILE 循环条件";
      if(draft.loopType==="FOREACH"&&!draft.foreachExpression?.trim())return "请输入遍历表达式";
    }
    if(draft.type==="condition"){
      if(draft.conditionType==="EXPRESSION"&&!draft.conditionExpression?.trim())return "请输入条件表达式";
      if(draft.conditionType==="SCRIPT"&&!draft.conditionExpression?.trim())return "条件脚本不能为空";
    }
    return "";
  };
  const save=()=>{
    const message=validate();
    if(message){setError(message);return;}
    setError("");setSaveState("saving");
    setTimeout(()=>{
      setSaveState("idle");
      onSave(draft);
    },650);
  };
  const tryClose=()=>dirty?setConfirmClose(true):onClose();
  const fieldStyle={width:"100%",height:34,border:`1px solid ${T.border}`,borderRadius:8,padding:"0 10px",fontSize:12,color:T.t1,outline:"none",background:"#fff"} as const;
  const areaStyle={width:"100%",border:`1px solid ${T.border}`,borderRadius:8,padding:"10px 12px",fontSize:12,color:T.t1,outline:"none",resize:"vertical" as const,fontFamily:"inherit",lineHeight:1.6,background:"#fff"};
  const Label=({children,required}:{children:React.ReactNode;required?:boolean})=>(
    <label className="block text-[12px] font-medium mb-1.5" style={{color:T.t2}}>
      {children}{required&&<span style={{color:T.danger}}> *</span>}
    </label>
  );
  const TypeOption=({value,label,active,onClick}:{value:string;label:string;active:boolean;onClick:()=>void})=>(
    <button type="button" onClick={onClick} className="h-8 px-3 rounded-lg border text-[12px] font-medium transition-colors"
      style={{borderColor:active?T.primary:T.border,background:active?"#E8F3FF":"#fff",color:active?T.primary:T.t2}}>
      {label}
    </button>
  );

  return(
    <div className="fixed inset-0 z-[80] flex justify-end" style={{background:"rgba(29,33,41,.38)"}}>
      <div className="h-full bg-white flex flex-col shadow-2xl" style={{width:720,borderLeft:`1px solid ${T.border}`}}>
        <div className="flex items-center gap-3 px-5 py-4 flex-shrink-0" style={{borderBottom:`1px solid ${T.border}`}}>
          <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{background:STEP_CFG[draft.type].bg}}>
            {React.createElement(STEP_CFG[draft.type].icon,{size:17,color:STEP_CFG[draft.type].color})}
          </div>
          <div className="flex-1">
            <h3 className="text-[15px] font-semibold" style={{color:T.t1}}>{isNew?"新建":"配置"}{STEP_CFG[draft.type].label}</h3>
            <p className="text-[11px] mt-0.5" style={{color:T.t3}}>{STEP_CFG[draft.type].desc}</p>
          </div>
          <button onClick={tryClose} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-gray-100" style={{color:T.t3}}><X size={16}/></button>
        </div>

        <div className="flex-1 overflow-y-auto p-5" style={{background:"#FAFBFE"}}>
          <div className="rounded-xl border bg-white p-4 mb-4" style={{borderColor:T.border}}>
            <Label required>步骤名称</Label>
            <input value={draft.name} onChange={e=>set("name",e.target.value)} style={fieldStyle} placeholder="请输入步骤名称"/>
          </div>

          {draft.type==="custom"&&(
            <div className="rounded-xl border bg-white overflow-hidden" style={{borderColor:T.border}}>
              <div className="p-4" style={{borderBottom:`1px solid ${T.border}`}}>
                <Label required>请求地址</Label>
                <div className="flex gap-2">
                  <select value={draft.method} onChange={e=>set("method",e.target.value as Method)}
                    style={{...fieldStyle,width:100,fontWeight:700,color:METHOD_STYLE[draft.method||"POST"].color}}>
                    {(["GET","POST","PUT","DELETE","PATCH"] as Method[]).map(method=><option key={method}>{method}</option>)}
                  </select>
                  <input value={draft.path||""} onChange={e=>set("path",e.target.value)} style={{...fieldStyle,flex:1,fontFamily:"monospace"}} placeholder="/api/orders"/>
                  <button onClick={()=>setDebugSent(true)} className="h-[34px] px-4 rounded-lg text-[12px] font-medium text-white flex items-center gap-1.5" style={{background:T.success}}>
                    <Play size={12}/>发送
                  </button>
                </div>
              </div>
              <div className="flex px-3 overflow-x-auto" style={{borderBottom:`1px solid ${T.border}`}}>
                {["Params","Auth","Headers","Cookies","Body","前置处理","后置处理","断言","设置"].map(tab=>(
                  <button key={tab} onClick={()=>setRequestTab(tab)} className="h-9 px-3 text-[12px] border-b-2"
                    style={{borderBottomColor:requestTab===tab?T.primary:"transparent",color:requestTab===tab?T.primary:T.t3}}>
                    {tab}
                  </button>
                ))}
              </div>
              <div className="p-4">
                {requestTab==="前置处理"||requestTab==="后置处理"
                  ? <div>
                      <div className="flex gap-2 mb-3">
                        {["脚本","SQL","等待"].map(type=>(
                          <button key={type} onClick={()=>{
                            const key=requestTab==="前置处理"?"preProcessorsText":"postProcessorsText";
                            setDraft(prev=>({...prev,[key]:`${prev[key]||""}${prev[key]?"\n":""}${type}处理器`}));
                          }} className="h-7 px-3 rounded-lg border text-[11px]" style={{borderColor:T.border,color:T.primary,background:"#fff"}}>
                            <Plus size={11} className="inline mr-1"/>添加{type}
                          </button>
                        ))}
                      </div>
                      <div className="space-y-2">
                        {((requestTab==="前置处理"?draft.preProcessorsText:draft.postProcessorsText)||"").split("\n").filter(Boolean).map((item,index)=>(
                          <div key={`${item}-${index}`} className="flex items-center gap-2 p-3 rounded-lg border" style={{borderColor:T.border}}>
                            <GripVertical size={13} style={{color:T.t4}}/><span className="text-[12px] flex-1" style={{color:T.t1}}>{item}</span>
                            <button className="text-[11px]" style={{color:T.primary}}>配置</button>
                            <button onClick={()=>{
                              const key=requestTab==="前置处理"?"preProcessorsText":"postProcessorsText";
                              const items=((draft[key] as string)||"").split("\n").filter(Boolean).filter((_,i)=>i!==index);
                              setDraft(prev=>({...prev,[key]:items.join("\n")}));
                            }} className="text-[11px]" style={{color:T.danger}}>删除</button>
                          </div>
                        ))}
                        {!((requestTab==="前置处理"?draft.preProcessorsText:draft.postProcessorsText)||"")&&<div className="py-8 text-center text-[12px]" style={{color:T.t4}}>暂无处理器</div>}
                      </div>
                    </div>
                  : requestTab==="断言"
                    ? <div>
                        <div className="grid grid-cols-[1fr_120px_1fr_auto] gap-2 items-center">
                          <input style={fieldStyle} placeholder="实际值，如 $.code"/>
                          <select style={fieldStyle}><option>等于</option><option>不等于</option><option>包含</option><option>存在</option></select>
                          <input value={draft.requestAssertionsText||""} onChange={e=>set("requestAssertionsText",e.target.value)} style={fieldStyle} placeholder="期望值"/>
                          <button className="h-[34px] px-3 rounded-lg text-[11px] text-white" style={{background:T.primary}}>添加</button>
                        </div>
                        <p className="text-[11px] mt-3" style={{color:T.t4}}>断言将作为数组条目保存，可继续添加多条响应断言。</p>
                      </div>
                    : requestTab==="设置"
                  ? <div className="grid grid-cols-2 gap-4">
                      <div><Label>响应超时 (ms)</Label><input type="number" value={draft.timeoutMs} onChange={e=>set("timeoutMs",+e.target.value)} style={fieldStyle}/></div>
                      <div><Label>连接超时 (ms)</Label><input type="number" value={draft.connectTimeoutMs} onChange={e=>set("connectTimeoutMs",+e.target.value)} style={fieldStyle}/></div>
                      <div className="col-span-2 flex items-center justify-between px-3 py-3 rounded-lg border" style={{borderColor:T.border}}>
                        <div><p className="text-[12px] font-medium" style={{color:T.t1}}>跟随重定向</p><p className="text-[11px] mt-0.5" style={{color:T.t4}}>自动跟随服务端返回的 3xx 跳转</p></div>
                        <Toggle on={!!draft.followRedirects} onToggle={()=>set("followRedirects",!draft.followRedirects)}/>
                      </div>
                    </div>
                  : <textarea
                      value={{
                        Params:draft.paramsText,Auth:draft.authText,Headers:draft.headersText,Cookies:draft.cookiesText,
                        Body:draft.bodyText,
                      }[requestTab]||""}
                      onChange={e=>{
                        const key={
                          Params:"paramsText",Auth:"authText",Headers:"headersText",Cookies:"cookiesText",Body:"bodyText",
                        }[requestTab] as keyof Step;
                        setDraft(prev=>({...prev,[key]:e.target.value}));
                      }}
                      rows={10} style={{...areaStyle,fontFamily:"monospace"}}
                      placeholder={`请输入 ${requestTab} 配置，支持 {{变量名}}`}
                    />
                }
              </div>
              {debugSent&&(
                <div className="p-4" style={{borderTop:`1px solid ${T.border}`,background:"#FAFBFE"}}>
                  <div className="flex items-center gap-3 mb-3">
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded" style={{background:"#E8FFEA",color:T.success}}>200 OK</span>
                    <span className="text-[11px]" style={{color:T.t3}}>342 ms · 1.2 KB</span>
                    <span className="ml-auto text-[11px]" style={{color:T.t4}}>单步调试响应</span>
                  </div>
                  <pre className="text-[11px] rounded-lg p-3 overflow-auto" style={{background:"#101827",color:"#DDE7F4",maxHeight:150}}>{`{\n  "code": 0,\n  "message": "success"\n}`}</pre>
                </div>
              )}
            </div>
          )}

          {draft.type==="script"&&(
            <div className="space-y-4">
              <div className="rounded-xl border bg-white p-4" style={{borderColor:T.border}}>
                <div className="flex items-center justify-between mb-1.5">
                  <Label required>JavaScript 脚本</Label>
                  <span className="text-[11px]" style={{color:T.t4}}>运行超时固定为 10 秒</span>
                </div>
                <textarea value={draft.script||""} onChange={e=>set("script",e.target.value)} rows={15}
                  style={{...areaStyle,fontFamily:"monospace",background:"#101827",color:"#DDE7F4",borderColor:"#243047"}}
                  placeholder={'// 独立脚本步骤没有上一步响应上下文\nvariables.set("status", "READY");'}/>
                <div className="flex flex-wrap gap-2 mt-3">
                  {["variables.get","variables.set","log","fail"].map(api=><code key={api} className="text-[10px] px-2 py-1 rounded" style={{background:T.bg,color:T.t2}}>{api}</code>)}
                </div>
              </div>
              <div className="rounded-xl border bg-white p-4" style={{borderColor:T.border}}>
                <Label>可选断言</Label>
                <div className="flex gap-2 mb-3">
                  <TypeOption value="VARIABLE" label="变量断言" active={draft.assertionType==="VARIABLE"} onClick={()=>set("assertionType","VARIABLE")}/>
                  <TypeOption value="SCRIPT" label="脚本断言" active={draft.assertionType==="SCRIPT"} onClick={()=>set("assertionType","SCRIPT")}/>
                </div>
                {draft.assertionType==="VARIABLE"
                  ? <div className="grid grid-cols-3 gap-2">
                      <input value={draft.assertionTarget||""} onChange={e=>set("assertionTarget",e.target.value)} style={fieldStyle} placeholder="变量名"/>
                      <select value={draft.assertionOperator||"等于"} onChange={e=>set("assertionOperator",e.target.value)} style={fieldStyle}><option>等于</option><option>不等于</option><option>包含</option><option>存在</option></select>
                      <input value={draft.assertionExpected||""} onChange={e=>set("assertionExpected",e.target.value)} style={fieldStyle} placeholder="期望值"/>
                    </div>
                  : <textarea value={draft.assertionScript||""} onChange={e=>set("assertionScript",e.target.value)} rows={5} style={{...areaStyle,fontFamily:"monospace"}} placeholder={'if (variables.get("status") !== "READY") fail("状态不正确");'}/>
                }
              </div>
            </div>
          )}

          {draft.type==="wait"&&(
            <div className="rounded-xl border bg-white p-5" style={{borderColor:T.border}}>
              <Label required>等待时长</Label>
              <div className="flex items-center gap-2" style={{maxWidth:360}}>
                <input type="number" min={1} max={60000} value={draft.delayMs}
                  onChange={e=>set("delayMs",+e.target.value)} style={{...fieldStyle,flex:1}}/>
                <span className="h-[34px] px-4 rounded-lg border flex items-center text-[12px]" style={{borderColor:T.border,color:T.t3}}>ms</span>
              </div>
              <p className="text-[11px] mt-2" style={{color:T.t4}}>允许范围 1–60000ms，默认 1000ms。</p>
            </div>
          )}

          {draft.type==="loop"&&(
            <div className="rounded-xl border bg-white p-5" style={{borderColor:T.border}}>
              <Label required>循环方式</Label>
              <div className="flex gap-2 mb-5">
                <TypeOption value="FIXED" label="固定次数" active={draft.loopType==="FIXED"} onClick={()=>set("loopType","FIXED")}/>
                <TypeOption value="WHILE" label="WHILE 条件" active={draft.loopType==="WHILE"} onClick={()=>set("loopType","WHILE")}/>
                <TypeOption value="FOREACH" label="遍历集合" active={draft.loopType==="FOREACH"} onClick={()=>set("loopType","FOREACH")}/>
              </div>
              {draft.loopType==="FIXED"&&(
                <div><Label required>循环次数</Label><input type="number" min={0} max={50} value={draft.loopCount} onChange={e=>set("loopCount",+e.target.value)} style={{...fieldStyle,maxWidth:280}}/><p className="text-[11px] mt-2" style={{color:T.t4}}>范围 0–50；0 表示跳过，当前索引可通过 loopIndex 获取。</p></div>
              )}
              {draft.loopType==="WHILE"&&(
                <div><Label required>循环条件</Label><textarea value={draft.conditionExpression||""} onChange={e=>set("conditionExpression",e.target.value)} rows={4} style={{...areaStyle,fontFamily:"monospace"}} placeholder={"{{status}} !== \"DONE\""}/><p className="text-[11px] mt-2" style={{color:T.warning}}>为避免无限循环，运行时最多执行 50 次。</p></div>
              )}
              {draft.loopType==="FOREACH"&&(
                <div><Label required>遍历表达式</Label><textarea value={draft.foreachExpression||""} onChange={e=>set("foreachExpression",e.target.value)} rows={4} style={{...areaStyle,fontFamily:"monospace"}} placeholder={"A,B,C\n或每行填写一项"}/><p className="text-[11px] mt-2" style={{color:T.t4}}>支持变量替换，按逗号或换行拆分，最多 50 项。</p><div className="flex gap-2 mt-3"><span className="text-[11px] px-2 py-1 rounded" style={{background:T.bg,color:T.t2}}>当前项：item</span><span className="text-[11px] px-2 py-1 rounded" style={{background:T.bg,color:T.t2}}>索引：loopIndex（从 0 开始）</span></div></div>
              )}
              <p className="text-[11px] mt-4 pt-3" style={{color:T.t4,borderTop:`1px dashed ${T.border}`}}>子步骤失败后的处理方式跟随场景“失败后继续执行”设置。</p>
            </div>
          )}

          {draft.type==="condition"&&(
            <div className="rounded-xl border bg-white p-5" style={{borderColor:T.border}}>
              <Label required>条件方式</Label>
              <div className="flex gap-2 mb-5">
                <TypeOption value="EXPRESSION" label="表达式" active={draft.conditionType==="EXPRESSION"} onClick={()=>set("conditionType","EXPRESSION")}/>
                <TypeOption value="SCRIPT" label="脚本" active={draft.conditionType==="SCRIPT"} onClick={()=>set("conditionType","SCRIPT")}/>
              </div>
              {draft.conditionType==="EXPRESSION"
                ? <div><Label required>条件表达式</Label><textarea value={draft.conditionExpression||""} onChange={e=>set("conditionExpression",e.target.value)} rows={5} style={{...areaStyle,fontFamily:"monospace"}} placeholder={"{{status}} == READY"}/><p className="text-[11px] mt-2" style={{color:T.t4}}>支持 ==、!=、&gt;、&gt;=、&lt;、&lt;=、contains；当前仅支持单条比较。</p></div>
                : <div><Label required>条件脚本</Label><textarea value={draft.conditionExpression||""} onChange={e=>set("conditionExpression",e.target.value)} rows={9} style={{...areaStyle,fontFamily:"monospace",background:"#101827",color:"#DDE7F4"}} placeholder={'// 执行成功表示条件成立；使用 fail(...) 表示不成立\nif (variables.get("status") !== "READY") fail("条件不成立");'}/><p className="text-[11px] mt-2" style={{color:T.t4}}>脚本内容同样保存到 conditionExpression。</p></div>
              }
              <div className="mt-4 p-3 rounded-lg" style={{background:"#E8F3FF",color:T.primary}}>
                <p className="text-[11px]">当前模型只执行条件成立分支，不支持 else 或 else if。</p>
              </div>
            </div>
          )}

          {draft.type==="once"&&(
            <div className="rounded-xl border bg-white p-5" style={{borderColor:T.border}}>
              <div className="flex items-start gap-3">
                <Info size={17} style={{color:T.primary,marginTop:1,flexShrink:0}}/>
                <div>
                  <p className="text-[13px] font-medium" style={{color:T.t1}}>单次场景执行内仅运行一次</p>
                  <p className="text-[12px] mt-1 leading-6" style={{color:T.t3}}>系统根据该步骤 ID 去重。第一次到达时执行内部子步骤，后续再次到达时自动跳过。每轮独立场景执行、每条测试数据都会重新计数，无需配置作用范围或去重键。</p>
                </div>
              </div>
            </div>
          )}

          {isControl&&(
            <div className="rounded-xl border bg-white mt-4 overflow-hidden" style={{borderColor:T.border}}>
              <div className="flex items-center justify-between px-4 py-3" style={{borderBottom:`1px solid ${T.border}`}}>
                <div>
                  <p className="text-[13px] font-semibold" style={{color:T.t1}}>{draft.type==="condition"?"条件成立时执行":"子步骤"}</p>
                  <p className="text-[11px] mt-0.5" style={{color:T.t4}}>当前嵌套层级 {draft.depth+1} / 3</p>
                </div>
                <Btn small icon={Plus} onClick={()=>setChildPicker(true)}>添加子步骤</Btn>
              </div>
              <div className="p-3">
                {(draft.children||[]).length===0
                  ? <div className="py-8 text-center text-[12px]" style={{color:T.t4}}>暂无子步骤</div>
                  : draft.children!.map((child,index)=>(
                    <div key={child.id} className="flex items-center gap-2 px-3 py-2 rounded-lg border mb-2" style={{borderColor:T.border}}>
                      <Toggle on={child.enabled} onToggle={()=>set("children",draft.children!.map((item,i)=>i===index?{...item,enabled:!item.enabled}:item))}/>
                      <StepBadge type={child.type}/><span className="flex-1 text-[12px]" style={{color:child.enabled?T.t1:T.t4}}>{child.name}</span>
                      <button disabled={index===0} onClick={()=>{
                        const children=[...draft.children!];[children[index-1],children[index]]=[children[index],children[index-1]];set("children",children);
                      }} style={{color:index===0?T.t4:T.t3}}><ArrowUp size={12}/></button>
                      <button disabled={index===draft.children!.length-1} onClick={()=>{
                        const children=[...draft.children!];[children[index+1],children[index]]=[children[index],children[index+1]];set("children",children);
                      }} style={{color:index===draft.children!.length-1?T.t4:T.t3}}><ArrowDown size={12}/></button>
                      <button onClick={()=>setEditingChild({step:child,index})} className="text-[11px]" style={{color:T.primary}}>配置</button>
                      <button onClick={()=>set("children",draft.children!.filter((_,i)=>i!==index))} className="text-[11px]" style={{color:T.danger}}>删除</button>
                    </div>
                  ))
                }
              </div>
            </div>
          )}

          {error&&(
            <div className="flex items-center gap-2 mt-4 px-3 py-2.5 rounded-lg text-[12px]" style={{background:"#FFF0F0",color:T.danger}}>
              <AlertCircle size={14}/>{error}
            </div>
          )}
        </div>

        <div className="flex items-center justify-between px-5 py-3.5 flex-shrink-0 bg-white" style={{borderTop:`1px solid ${T.border}`}}>
          <span className="text-[11px]" style={{color:T.t4}}>{dirty?"存在未保存的修改":"所有修改已保存"}</span>
          <div className="flex gap-2">
            <Btn ghost onClick={tryClose}>取消</Btn>
            <Btn icon={saveState==="saving"?RefreshCw:Save} disabled={saveState==="saving"} onClick={save}>
              {saveState==="saving"?"保存中…":isNew?"保存并添加":"保存修改"}
            </Btn>
          </div>
        </div>
      </div>

      {childPicker&&(
        <div className="fixed inset-0 z-[90] flex items-center justify-center" style={{background:"rgba(29,33,41,.4)"}}>
          <div className="bg-white rounded-2xl shadow-2xl overflow-hidden" style={{width:560}}>
            <div className="flex items-center justify-between px-5 py-4" style={{borderBottom:`1px solid ${T.border}`}}>
              <p className="text-[14px] font-semibold" style={{color:T.t1}}>选择子步骤类型</p>
              <button onClick={()=>setChildPicker(false)} style={{color:T.t3}}><X size={15}/></button>
            </div>
            <div className="grid grid-cols-2 gap-3 p-4">
              {ADD_STEP_TYPES.map(type=>{
                const control=type==="loop"||type==="condition"||type==="once";
                const disabled=maxDepthReached&&control;
                const cfg=STEP_CFG[type];
                return(
                  <button key={type} disabled={disabled} onClick={()=>{
                    setChildPicker(false);
                    if(type==="ref-api")setChildResourcePicker("api");
                    else if(type==="ref-case")setChildResourcePicker("case");
                    else if(type==="ref-scene")setChildResourcePicker("scene");
                    else setEditingChild({step:createStepDraft(type,draft.depth+1),index:null});
                  }} className="flex items-center gap-3 p-3 rounded-xl border text-left"
                    style={{borderColor:T.border,opacity:disabled?0.45:1,cursor:disabled?"not-allowed":"pointer"}}>
                    <span className="w-8 h-8 rounded-lg flex items-center justify-center" style={{background:cfg.bg}}>{React.createElement(cfg.icon,{size:15,color:cfg.color})}</span>
                    <span><span className="block text-[12px] font-semibold" style={{color:T.t1}}>{cfg.label}</span><span className="block text-[10px] mt-0.5" style={{color:T.t4}}>{disabled?"已达到最大嵌套深度":cfg.desc}</span></span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {childResourcePicker&&(
        <div className="fixed inset-0 z-[95]">
          <ResourcePickerDialog
            resourceType={childResourcePicker}
            currentSceneId={currentSceneId}
            onClose={steps=>{
              if(steps.length){
                set("children",[...(draft.children||[]),...steps.map(item=>({...item,depth:draft.depth+1}))]);
              }
              setChildResourcePicker(null);
            }}
          />
        </div>
      )}

      {editingChild&&(
        <StepConfigDrawer
          key={editingChild.step.id}
          step={editingChild.step}
          isNew={editingChild.index===null}
          currentSceneId={currentSceneId}
          onSave={saved=>{
            const children=[...(draft.children||[])];
            if(editingChild.index===null)children.push(saved);
            else children[editingChild.index]=saved;
            set("children",children);
            setEditingChild(null);
          }}
          onClose={()=>setEditingChild(null)}
        />
      )}

      {confirmClose&&(
        <div className="fixed inset-0 z-[110] flex items-center justify-center" style={{background:"rgba(29,33,41,.48)"}}>
          <div className="bg-white rounded-2xl shadow-2xl p-5" style={{width:400}}>
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{background:"#FFF3E8"}}><AlertTriangle size={17} style={{color:T.warning}}/></div>
              <div><h4 className="text-[14px] font-semibold" style={{color:T.t1}}>放弃未保存的修改？</h4><p className="text-[12px] mt-1 leading-5" style={{color:T.t3}}>关闭后，本次填写的配置将不会保留。</p></div>
            </div>
            <div className="flex justify-end gap-2 mt-5">
              <Btn ghost onClick={()=>setConfirmClose(false)}>继续编辑</Btn>
              <Btn danger onClick={onClose}>放弃修改</Btn>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Step Row ─────────────────────────────────────────────────────────────────
function StepRow({step,index,total,onToggle,onDelete,onMoveUp,onMoveDown,onCopy,onConfig,onUpdateChildren}:{
  step:Step;index:number;total:number;
  onToggle:()=>void;onDelete:()=>void;onMoveUp:()=>void;onMoveDown:()=>void;onCopy:()=>void;onConfig:(step:Step)=>void;
  onUpdateChildren?:(children:Step[])=>void;
}){
  const isCtrl=step.type==="loop"||step.type==="condition"||step.type==="once";
  const rowBg=step.depth>0?"#FAFBFF":"#fff";
  return(
    <div>
      <div className="flex items-center gap-2 px-3 py-2.5 group rounded-lg transition-colors"
        style={{paddingLeft:12+step.depth*20,backgroundColor:rowBg,opacity:step.enabled?1:.5,
          borderLeft:isCtrl?`3px solid ${STEP_CFG[step.type].color}`:"3px solid transparent"}}>
        {/* Drag handle */}
        <GripVertical size={14} className="flex-shrink-0 opacity-30 cursor-grab group-hover:opacity-60" style={{color:T.t3}}/>
        {/* Toggle */}
        <Toggle on={step.enabled} onToggle={onToggle}/>
        {/* Index */}
        <span className="w-5 text-center text-[11px] flex-shrink-0" style={{color:T.t4}}>{index+1}</span>
        {/* Step type badge */}
        <StepBadge type={step.type}/>
        {/* Method badge (for HTTP steps) */}
        {step.method&&<MethodTag m={step.method}/>}
        {/* Name */}
        <span className="flex-1 text-[13px] truncate" style={{color:T.t1}}>{step.name}</span>
        {/* Path (for HTTP steps) */}
        {step.path&&<span className="text-[11px] font-mono truncate max-w-[200px]" style={{color:T.t3}}>{step.path}</span>}
        {/* Children count (for controllers) */}
        {isCtrl&&step.children&&(
          <span className="text-[11px] px-1.5 py-0.5 rounded" style={{backgroundColor:STEP_CFG[step.type].bg,color:STEP_CFG[step.type].color}}>
            {step.children.length} 子步骤
          </span>
        )}
        {/* Actions */}
        <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
          <IBtn icon={ChevronRight} label="配置" onClick={()=>onConfig(step)}/>
          <IBtn icon={ArrowUp} label="上移" onClick={onMoveUp} disabled={index===0}/>
          <IBtn icon={ArrowDown} label="下移" onClick={onMoveDown} disabled={index===total-1}/>
          <IBtn icon={Copy} label="复制" onClick={onCopy}/>
          <IBtn icon={Trash2} label="删除" danger onClick={onDelete}/>
        </div>
      </div>
      {/* Nested children */}
      {isCtrl&&step.children&&step.children.map((child,ci)=>{
        const ch=step.children!;
        const upd=(next:Step[])=>onUpdateChildren?.(next);
        return(
          <StepRow key={child.id} step={child} index={ci} total={ch.length}
            onToggle={()=>upd(ch.map(c=>c.id===child.id?{...c,enabled:!c.enabled}:c))}
            onDelete={()=>upd(ch.filter(c=>c.id!==child.id))}
            onMoveUp={()=>{if(ci===0)return;const a=[...ch];[a[ci],a[ci-1]]=[a[ci-1],a[ci]];upd(a);}}
            onMoveDown={()=>{if(ci===ch.length-1)return;const a=[...ch];[a[ci],a[ci+1]]=[a[ci+1],a[ci]];upd(a);}}
            onCopy={()=>{const a=[...ch];a.splice(ci+1,0,{...child,id:`st${Date.now()}`,name:child.name+" (副本)"});upd(a);}}
            onConfig={onConfig}/>
        );
      })}
      {/* Add child step button for controllers */}
      {isCtrl&&(
        <button onClick={()=>onConfig(step)} className="flex items-center gap-1.5 text-[11px] py-1.5 rounded-lg transition-colors"
          style={{paddingLeft:32+step.depth*20,color:STEP_CFG[step.type].color}}>
          <Plus size={11}/>添加子步骤
        </button>
      )}
    </div>
  );
}

// ─── Test Data Tab ────────────────────────────────────────────────────────────
function TestDataTab(){
  const[datasets]=useState([{id:"ds1",name:"注册测试数据集",enabled:true,rows:5},{id:"ds2",name:"批量导入数据",enabled:false,rows:20}]);
  const[selDs,setSelDs]=useState("ds1");
  const cols=["描述(caseDesc)","用户名","密码","手机号","期望状态"];
  const rows=[
    ["正常注册","user_001","Aa123456","13800001001","success"],
    ["重复手机号","user_002","Aa123456","13800001001","fail"],
    ["弱密码","user_003","123456","13800001003","fail"],
    ["正常注册2","user_004","Aa123456","13800001004","success"],
    ["特殊字符","user_005","Aa!@#456","13800001005","success"],
  ];
  return(
    <div className="flex-1 flex overflow-hidden">
      {/* Left: dataset list */}
      <div className="flex-shrink-0 border-r overflow-y-auto" style={{width:220,borderColor:T.border}}>
        <div className="p-3">
          <div className="flex items-center justify-between mb-2">
            <p className="text-[12px] font-semibold" style={{color:T.t2}}>数据集列表</p>
            <button className="w-6 h-6 flex items-center justify-center rounded hover:bg-gray-100"><Plus size={13} style={{color:T.primary}}/></button>
          </div>
          {datasets.map(ds=>(
            <div key={ds.id} onClick={()=>setSelDs(ds.id)}
              className="flex items-center gap-2 p-2.5 rounded-lg cursor-pointer mb-1 transition-colors"
              style={{backgroundColor:selDs===ds.id?"#E8F3FF":"transparent"}}>
              <Toggle on={ds.enabled} onToggle={()=>{}}/>
              <div className="flex-1 min-w-0">
                <p className="text-[12px] font-medium truncate" style={{color:selDs===ds.id?T.primary:T.t1}}>{ds.name}</p>
                <p className="text-[11px]" style={{color:T.t3}}>{ds.rows} 行数据</p>
              </div>
              <IBtn icon={MoreHorizontal} label="操作"/>
            </div>
          ))}
        </div>
      </div>
      {/* Right: dataset editor */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Toolbar */}
        <div className="flex items-center gap-2 px-4 py-2.5 flex-shrink-0" style={{borderBottom:`1px solid ${T.border}`}}>
          <p className="text-[13px] font-semibold flex-1" style={{color:T.t1}}>注册测试数据集</p>
          <Btn ghost small icon={Upload}>导入 CSV</Btn>
          <Btn ghost small icon={Database}>导入 JSON</Btn>
          <div className="w-px h-4 mx-1" style={{backgroundColor:T.border}}/>
          <Btn ghost small icon={Database}>导出 CSV</Btn>
          <Btn ghost small>添加变量列</Btn>
          <Btn small icon={Plus} color={T.success}>添加数据行</Btn>
        </div>
        {/* Table */}
        <div className="flex-1 overflow-auto">
          <table className="text-[12px]" style={{minWidth:"100%"}}>
            <thead>
              <tr style={{backgroundColor:T.bg,position:"sticky",top:0}}>
                <th className="px-3 py-2 text-left font-medium w-8" style={{color:T.t3}}>#</th>
                {cols.map(c=>(
                  <th key={c} className="px-3 py-2 text-left font-medium whitespace-nowrap" style={{color:T.t3,minWidth:120}}>
                    <div className="flex items-center gap-1">{c}<IBtn icon={Trash2} label="删除列" danger/></div>
                  </th>
                ))}
                <th className="px-3 py-2 w-8"/>
              </tr>
            </thead>
            <tbody>
              {rows.map((row,ri)=>(
                <tr key={ri} style={{borderBottom:`1px solid ${T.border}`}} className="hover:bg-blue-50/30">
                  <td className="px-3 py-2 text-center" style={{color:T.t4}}>{ri+1}</td>
                  {row.map((cell,ci)=>(
                    <td key={ci} className="px-2 py-1.5">
                      <input defaultValue={cell} className="w-full h-6 px-2 border rounded text-[11px] outline-none" style={{borderColor:"transparent",color:T.t1,backgroundColor:"transparent"}}
                        onFocus={e=>{e.target.style.borderColor=T.primary;e.target.style.backgroundColor="#fff";}}
                        onBlur={e=>{e.target.style.borderColor="transparent";e.target.style.backgroundColor="transparent";}}/>
                    </td>
                  ))}
                  <td className="px-2 py-1.5"><IBtn icon={Trash2} label="删除行" danger/></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ─── Scene Settings Tab ───────────────────────────────────────────────────────
function SceneSettingsTab(){
  return(
    <div className="flex-1 overflow-y-auto p-6">
      <div className="max-w-lg space-y-5">
        {[
          {label:"失败后继续执行",desc:"单步失败后继续执行后续步骤",type:"toggle",default:false},
          {label:"全局超时时间 (ms)",desc:"整个场景的最大执行时间",type:"number",default:"30000"},
          {label:"步骤失败重试次数",desc:"单步失败时自动重试次数，0 表示不重试",type:"number",default:"0"},
          {label:"步骤间默认等待 (ms)",desc:"每个步骤执行前的默认等待时间",type:"number",default:"0"},
        ].map(item=>(
          <div key={item.label} className="flex items-center justify-between p-4 rounded-xl border" style={{borderColor:T.border}}>
            <div>
              <p className="text-[13px] font-medium" style={{color:T.t1}}>{item.label}</p>
              <p className="text-[12px] mt-0.5" style={{color:T.t3}}>{item.desc}</p>
            </div>
            {item.type==="toggle"
              ? <Toggle on={item.default as boolean} onToggle={()=>{}}/>
              : <input type="number" defaultValue={item.default as string}
                  className="h-8 w-24 px-3 border rounded-lg text-[13px] text-right outline-none"
                  style={{borderColor:T.border}}/>
            }
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Step Detail Drawer ───────────────────────────────────────────────────────
interface StepDetailInfo { name:string; status:"pass"|"fail"; duration:string; index:number; }
function StepDetailDrawer({step,onClose}:{step:StepDetailInfo;onClose:()=>void}){
  const isFail=step.status==="fail";
  const[tab,setTab]=useState(isFail?"断言":"请求");
  const tabs=["请求","响应","断言",...(isFail?["错误信息"]:[])] as const;

  const reqBody=JSON.stringify({userId:"usr_12345",items:[{productId:"prod_001",quantity:2,price:99.00}],addressId:"addr_789",paymentMethod:"alipay"},null,2);
  const resBodyOk=JSON.stringify({code:0,message:"success",data:{orderId:"ord_20261012_001",status:"pending",totalAmount:198.00}},null,2);
  const resBodyFail=JSON.stringify({code:404,message:"Resource not found",traceId:"trace_abc123"},null,2);

  const assertions=[
    {desc:"HTTP 状态码为 200",     expected:"200",    actual:isFail?"404":"200",  pass:!isFail},
    {desc:"响应 code 字段为 0",    expected:"0",      actual:isFail?"404":"0",    pass:!isFail},
    {desc:"响应包含 orderId 字段", expected:"字段存在", actual:isFail?"字段缺失":"字段存在", pass:!isFail},
    {desc:"响应时间 < 2000ms",     expected:"< 2000ms",actual:step.duration,       pass:true},
  ];

  return(
    <>
      <div onClick={onClose} style={{position:"fixed",inset:0,background:"transparent",zIndex:1200}}/>
      <div style={{position:"fixed",top:0,right:0,bottom:0,width:620,zIndex:1201,background:"#fff",boxShadow:"-8px 0 40px rgba(0,0,0,0.18)",display:"flex",flexDirection:"column"}}>
        {/* Header */}
        <div style={{flexShrink:0,padding:"14px 20px 0",borderBottom:`1px solid ${T.border}`,background:"#FAFBFE"}}>
          <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:10}}>
            <div style={{flex:1}}>
              <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:3}}>
                <span style={{fontSize:14,fontWeight:700,color:T.t1}}>步骤 {step.index+1} · {step.name}</span>
                {isFail
                  ?<span style={{fontSize:11,padding:"1px 8px",borderRadius:20,background:"#FFF0F0",color:T.danger,fontWeight:600}}>失败</span>
                  :<span style={{fontSize:11,padding:"1px 8px",borderRadius:20,background:"#E8F8EF",color:T.success,fontWeight:600}}>通过</span>
                }
              </div>
              <div style={{display:"flex",gap:12,fontSize:11,color:T.t3}}>
                <span>耗时：<strong style={{color:T.t1,fontFamily:"'JetBrains Mono',monospace"}}>{step.duration}</strong></span>
                {isFail&&<span style={{color:T.danger}}>HTTP 404 · AssertionError</span>}
                {!isFail&&<span style={{color:T.success}}>HTTP 200 · 全部断言通过</span>}
              </div>
            </div>
            <button onClick={onClose} style={{background:"none",border:"none",cursor:"pointer",color:T.t3,padding:4}}><X size={15}/></button>
          </div>
          <div style={{display:"flex"}}>
            {tabs.map(t=>(
              <button key={t} onClick={()=>setTab(t as typeof tab)}
                style={{height:34,padding:"0 14px",border:"none",borderBottom:`2px solid ${tab===t?T.primary:"transparent"}`,background:"transparent",fontSize:12,fontWeight:500,color:tab===t?T.primary:T.t3,cursor:"pointer"}}>
                {t}
              </button>
            ))}
          </div>
        </div>
        {/* Body */}
        <div style={{flex:1,overflowY:"auto"}}>
          {tab==="请求"&&(
            <div style={{padding:20}}>
              <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:16}}>
                <span style={{padding:"3px 10px",borderRadius:5,background:"#E8F3FF",color:T.primary,fontSize:12,fontWeight:700}}>POST</span>
                <code style={{fontSize:12,color:T.t1,fontFamily:"'JetBrains Mono',monospace"}}>https://api-test.company.com/api/v1/orders</code>
              </div>
              <p style={{fontSize:11,fontWeight:600,color:T.t3,marginBottom:8,letterSpacing:"0.05em"}}>HEADERS</p>
              <div style={{borderRadius:8,border:`1px solid ${T.border}`,overflow:"hidden",marginBottom:16}}>
                {[["Content-Type","application/json"],["Authorization","Bearer eyJhbGciOiJIUzI1NiJ9..."],["X-Tenant-ID","tenant_001"]].map(([k,v])=>(
                  <div key={k} style={{display:"flex",borderBottom:`1px solid ${T.border}`,fontSize:12}}>
                    <div style={{width:160,padding:"7px 12px",background:"#FAFAFA",color:T.t3,fontFamily:"monospace",flexShrink:0}}>{k}</div>
                    <div style={{flex:1,padding:"7px 12px",color:T.t1,fontFamily:"monospace",wordBreak:"break-all"}}>{v}</div>
                  </div>
                ))}
              </div>
              <p style={{fontSize:11,fontWeight:600,color:T.t3,marginBottom:8,letterSpacing:"0.05em"}}>BODY</p>
              <pre style={{margin:0,padding:14,background:"#FAFAFA",borderRadius:8,border:`1px solid ${T.border}`,fontSize:11,color:T.t1,fontFamily:"'JetBrains Mono',monospace",overflow:"auto",lineHeight:1.7}}>{reqBody}</pre>
            </div>
          )}
          {tab==="响应"&&(
            <div style={{padding:20}}>
              <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:16}}>
                <span style={{padding:"3px 10px",borderRadius:5,background:isFail?"#FFF0F0":"#E8F8EF",color:isFail?T.danger:T.success,fontSize:13,fontWeight:700}}>{isFail?404:200}</span>
                <span style={{fontSize:12,color:T.t3}}>{isFail?"Not Found":"OK"}</span>
                <span style={{fontSize:11,color:T.t4,marginLeft:"auto",fontFamily:"monospace"}}>{step.duration}</span>
              </div>
              <p style={{fontSize:11,fontWeight:600,color:T.t3,marginBottom:8,letterSpacing:"0.05em"}}>HEADERS</p>
              <div style={{borderRadius:8,border:`1px solid ${T.border}`,overflow:"hidden",marginBottom:16}}>
                {[["Content-Type","application/json"],["X-Request-ID","req_abc123def456"]].map(([k,v])=>(
                  <div key={k} style={{display:"flex",borderBottom:`1px solid ${T.border}`,fontSize:12}}>
                    <div style={{width:160,padding:"7px 12px",background:"#FAFAFA",color:T.t3,fontFamily:"monospace",flexShrink:0}}>{k}</div>
                    <div style={{flex:1,padding:"7px 12px",color:T.t1,fontFamily:"monospace"}}>{v}</div>
                  </div>
                ))}
              </div>
              <p style={{fontSize:11,fontWeight:600,color:T.t3,marginBottom:8,letterSpacing:"0.05em"}}>BODY</p>
              <pre style={{margin:0,padding:14,background:isFail?"#FFF9F9":"#F9FFF9",borderRadius:8,border:`1px solid ${isFail?T.danger+"30":T.success+"30"}`,fontSize:11,color:T.t1,fontFamily:"'JetBrains Mono',monospace",overflow:"auto",lineHeight:1.7}}>{isFail?resBodyFail:resBodyOk}</pre>
            </div>
          )}
          {tab==="断言"&&(
            <div style={{padding:20}}>
              <div style={{display:"flex",flexDirection:"column",gap:8}}>
                {assertions.map((a,i)=>(
                  <div key={i} style={{display:"flex",alignItems:"flex-start",gap:12,padding:"12px 14px",borderRadius:8,border:`1px solid ${a.pass?T.success+"30":T.danger+"40"}`,background:a.pass?"#F9FFF9":"#FFF9F9"}}>
                    <div style={{flexShrink:0,marginTop:1}}>
                      {a.pass?<CheckCircle size={14} style={{color:T.success}}/>:<XCircle size={14} style={{color:T.danger}}/>}
                    </div>
                    <div style={{flex:1}}>
                      <p style={{fontSize:12,fontWeight:500,color:T.t1,marginBottom:5}}>{a.desc}</p>
                      <div style={{display:"flex",gap:20,fontSize:11,fontFamily:"'JetBrains Mono',monospace"}}>
                        <span style={{color:T.t3}}>期望：<span style={{color:T.success}}>{a.expected}</span></span>
                        <span style={{color:T.t3}}>实际：<span style={{color:a.pass?T.success:T.danger}}>{a.actual}</span></span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          {tab==="错误信息"&&isFail&&(
            <div style={{padding:20}}>
              <div style={{padding:14,borderRadius:8,background:"#FFF5F5",border:`1px solid ${T.danger}30`,marginBottom:16}}>
                <p style={{fontSize:12,fontWeight:600,color:T.danger,marginBottom:6}}>AssertionError</p>
                <p style={{fontSize:12,color:T.t1,lineHeight:1.7}}>断言失败：期望 HTTP 状态码为 <code style={{background:"#FFE8E8",padding:"1px 5px",borderRadius:3}}>200</code>，实际为 <code style={{background:"#FFE8E8",padding:"1px 5px",borderRadius:3}}>404</code></p>
              </div>
              <p style={{fontSize:11,fontWeight:600,color:T.t3,marginBottom:8,letterSpacing:"0.05em"}}>STACK TRACE</p>
              <pre style={{margin:0,padding:14,background:"#FAFAFA",borderRadius:8,border:`1px solid ${T.border}`,fontSize:10,color:T.t2,fontFamily:"'JetBrains Mono',monospace",lineHeight:1.8,overflow:"auto"}}>{`AssertionError: expected 200 to equal 404
  at StepRunner.assert (/runner/lib/assert.js:42:11)
  at StepRunner.executeStep (/runner/lib/runner.js:128:5)
  at SceneRunner.run (/runner/lib/scene.js:87:12)
  at process.nextTick (/runner/lib/executor.js:34:7)`}</pre>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

// ─── Scene Result Drawer (lightweight, avoids circular dep with ApiSceneExtras) ──
function SceneResultDrawer({runId,history,onClose}:{runId:string;history:SceneRunHistory[];onClose:()=>void}){
  const run=history.find(h=>h.id===runId);
  const[activeTab,setActiveTab]=useState("步骤列表");
  const tabs=["步骤列表","运行日志"];
  const[stepDetail,setStepDetail]=useState<StepDetailInfo|null>(null);
  const mockSteps=[
    {id:"s1",name:"获取登录 Token",type:"custom" as StepType,duration:"312ms",status:"pass"},
    {id:"s2",name:"查询商品列表",type:"ref-api" as StepType,duration:"205ms",status:"pass"},
    {id:"s3",name:"添加商品到购物车",type:"ref-api" as StepType,duration:"187ms",status:"pass"},
    {id:"s4",name:"创建订单",type:"ref-api" as StepType,duration:"423ms",status:"pass"},
    {id:"s5",name:"发起支付",type:"ref-api" as StepType,duration:"891ms",status:run?.status==="fail"?"fail":"pass"},
    {id:"s6",name:"查询支付状态",type:"ref-api" as StepType,duration:"144ms",status:run?.status==="fail"?"fail":"pass"},
    {id:"s7",name:"等待 2000ms",type:"wait" as StepType,duration:"2000ms",status:"pass"},
    {id:"s8",name:"断言订单状态为已完成",type:"script" as StepType,duration:"12ms",status:run?.status==="fail"?"fail":"pass"},
  ].slice(0,run?.stepsTotal??8);
  const passCount=mockSteps.filter(s=>s.status==="pass").length;
  const failCount=mockSteps.filter(s=>s.status==="fail").length;

  return(
    <>
      <div onClick={onClose} style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.22)",zIndex:1000}}/>
      <div style={{position:"fixed",top:0,right:0,bottom:0,width:860,zIndex:1001,background:"#fff",boxShadow:"-4px 0 32px rgba(0,0,0,0.14)",display:"flex",flexDirection:"column"}}>
        {/* Header */}
        <div style={{flexShrink:0,borderBottom:`1px solid ${T.border}`,background:"#FAFBFE",padding:"14px 24px 0"}}>
          <div style={{display:"flex",alignItems:"flex-start",gap:12,marginBottom:10}}>
            <div style={{flex:1}}>
              <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:4}}>
                <span style={{fontSize:15,fontWeight:700,color:T.t1}}>场景执行结果</span>
                {run?.status==="pass"&&<span style={{fontSize:11,padding:"1px 8px",borderRadius:20,background:"#E8F8EF",color:T.success,fontWeight:600}}>通过</span>}
                {run?.status==="fail"&&<span style={{fontSize:11,padding:"1px 8px",borderRadius:20,background:"#FFF0F0",color:T.danger,fontWeight:600}}>失败</span>}
                {run?.status==="cancelled"&&<span style={{fontSize:11,padding:"1px 8px",borderRadius:20,background:"#F4F6FA",color:T.t3,fontWeight:600}}>已取消</span>}
              </div>
              <div style={{display:"flex",gap:16,fontSize:12,color:T.t3}}>
                <span><span style={{color:T.t4}}>执行人：</span>{run?.operator}</span>
                <span><span style={{color:T.t4}}>开始时间：</span>{run?.runAt}</span>
                <span><span style={{color:T.t4}}>总耗时：</span><strong style={{color:T.t1}}>{run?.duration}</strong></span>
                <span><span style={{color:T.t4}}>运行环境：</span>{run?.env}</span>
              </div>
            </div>
            <div style={{display:"flex",gap:6}}>
              <button style={{display:"flex",alignItems:"center",gap:5,padding:"6px 14px",border:`1px solid ${T.border}`,borderRadius:7,background:"#fff",fontSize:12,color:T.t2,cursor:"pointer"}}><Play size={12}/>重新执行</button>
              <button onClick={onClose} style={{background:"none",border:"none",cursor:"pointer",color:T.t3,padding:4}}><X size={16}/></button>
            </div>
          </div>
          {/* Stats bar */}
          <div style={{display:"flex",gap:20,marginBottom:10}}>
            {[{label:"总步骤",value:mockSteps.length,color:T.t1},{label:"成功",value:passCount,color:T.success},{label:"失败",value:failCount,color:T.danger}].map(s=>(
              <div key={s.label} style={{display:"flex",alignItems:"center",gap:5}}>
                <span style={{fontSize:20,fontWeight:800,color:s.color}}>{s.value}</span>
                <span style={{fontSize:12,color:T.t3}}>{s.label}</span>
              </div>
            ))}
          </div>
          {/* Tabs */}
          <div style={{display:"flex"}}>
            {tabs.map(t=>(
              <button key={t} onClick={()=>setActiveTab(t)} style={{height:36,padding:"0 14px",border:"none",borderBottom:`2px solid ${activeTab===t?T.primary:"transparent"}`,background:"transparent",fontSize:12,fontWeight:500,color:activeTab===t?T.primary:T.t3,cursor:"pointer"}}>{t}</button>
            ))}
          </div>
        </div>
        {/* Body */}
        <div style={{flex:1,overflowY:"auto"}}>
          {activeTab==="步骤列表"&&(
            <table style={{width:"100%",borderCollapse:"collapse",fontSize:12}}>
              <thead>
                <tr style={{background:"#FAFAFA",borderBottom:`1px solid ${T.border}`,position:"sticky",top:0}}>
                  {["#","步骤名称","类型","耗时","状态"].map((h,i)=>(
                    <th key={i} style={{padding:"8px 16px",textAlign:"left",fontSize:11,fontWeight:600,color:T.t3}}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {mockSteps.map((step,i)=>{
                  const cfg=STEP_CFG[step.type]||{label:step.type,color:T.t3,bg:T.bg,icon:Settings};
                  const Icon=cfg.icon;
                  return(
                    <tr key={step.id} onClick={()=>setStepDetail({name:step.name,status:step.status as "pass"|"fail",duration:step.duration,index:i})}
                      style={{borderBottom:`1px solid ${T.border}`,background:step.status==="fail"?"#FFF5F5":"#fff",cursor:"pointer"}}
                      onMouseEnter={e=>e.currentTarget.style.background=step.status==="fail"?"#FFEEEE":"#F5F7FF"}
                      onMouseLeave={e=>e.currentTarget.style.background=step.status==="fail"?"#FFF5F5":"#fff"}>
                      <td style={{padding:"10px 16px",color:T.t4,fontSize:11}}>{i+1}</td>
                      <td style={{padding:"10px 16px",fontWeight:500,color:T.primary}}>{step.name}</td>
                      <td style={{padding:"10px 16px"}}>
                        <span style={{display:"inline-flex",alignItems:"center",gap:4,padding:"2px 8px",borderRadius:5,background:cfg.bg,color:cfg.color,fontSize:11}}>
                          <Icon size={11}/>{cfg.label}
                        </span>
                      </td>
                      <td style={{padding:"10px 16px",fontFamily:"'JetBrains Mono',monospace",color:T.t3,fontSize:11}}>{step.duration}</td>
                      <td style={{padding:"10px 16px"}}>
                        {step.status==="pass"
                          ?<span style={{display:"inline-flex",alignItems:"center",gap:4,color:T.success,fontSize:11}}><CheckCircle size={13}/>通过</span>
                          :<span style={{display:"inline-flex",alignItems:"center",gap:4,color:T.danger,fontSize:11}}><XCircle size={13}/>失败</span>
                        }
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
          {activeTab==="运行日志"&&(
            <div style={{padding:24,fontFamily:"'JetBrains Mono',monospace",fontSize:11,color:T.t2,lineHeight:1.8}}>
              {mockSteps.map((step,i)=>(
                <div key={step.id}>
                  <span style={{color:T.t4}}>[{step.duration}] </span>
                  <span style={{color:step.status==="fail"?T.danger:T.success}}>{step.status==="pass"?"✓":"✗"} </span>
                  <span>Step {i+1}: {step.name}</span>
                  {step.status==="fail"&&<span style={{color:T.danger}}> → AssertionError: expected 200 got 404</span>}
                  <br/>
                </div>
              ))}
            </div>
          )}
        </div>
        {stepDetail&&<StepDetailDrawer step={stepDetail} onClose={()=>setStepDetail(null)}/>}
      </div>
    </>
  );
}

// ─── Scene History Tab ────────────────────────────────────────────────────────
function SceneHistoryTab({onOpenDetail}:{onOpenDetail:(id:string)=>void}){
  const triggerMeta:Record<TriggerType,{label:string;color:string}>={
    manual:    {label:"手动",   color:T.t2},
    scheduled: {label:"定时",   color:T.cyan},
    ci:        {label:"CI/CD", color:T.purple},
  };

  return(
    <div className="flex-1 overflow-y-auto p-5">
      <div className="flex items-center justify-between mb-4">
        <p className="text-[13px] font-semibold" style={{color:T.t1}}>运行记录</p>
        <Btn ghost small icon={RefreshCw}>刷新</Btn>
      </div>
      <table className="w-full text-[12px]">
        <thead>
          <tr style={{backgroundColor:T.bg,borderBottom:`1px solid ${T.border}`}}>
            {["开始时间","环境","步骤通过/总数","耗时","触发方式","执行人","状态","操作"].map((h,i)=>(
              <th key={h} className={`px-4 py-2.5 text-left font-medium ${i===7?"text-right":""}`} style={{color:T.t3}}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {MOCK_SCENE_HISTORY.map((r,i)=>{
            const tm=triggerMeta[r.trigger];
            return(
              <tr key={r.id} className="hover:bg-blue-50/30" style={{borderBottom:`1px solid ${T.border}`,backgroundColor:i%2===0?"#fff":"#FAFBFE"}}>
                <td className="px-4 py-3 font-mono text-[11px]" style={{color:T.t2}}>{r.runAt}</td>
                <td className="px-4 py-3" style={{color:T.t2}}>{r.env}</td>
                <td className="px-4 py-3">
                  <span className="font-bold" style={{color:r.stepsPass===r.stepsTotal?T.success:T.danger}}>{r.stepsPass}</span>
                  <span style={{color:T.t3}}> / {r.stepsTotal}</span>
                </td>
                <td className="px-4 py-3 font-mono text-[11px]" style={{color:T.t2}}>{r.duration}</td>
                <td className="px-4 py-3">
                  <span className="text-[11px] px-1.5 py-0.5 rounded border"
                    style={{color:tm.color,borderColor:tm.color+"40",backgroundColor:tm.color+"0D"}}>
                    {tm.label}
                  </span>
                </td>
                <td className="px-4 py-3" style={{color:T.t2}}>{r.operator}</td>
                <td className="px-4 py-3"><StatusDot status={r.status==="cancelled"?null:r.status}/></td>
                <td className="px-4 py-3 text-right">
                  <IBtn icon={Eye} label="查看详情" onClick={()=>onOpenDetail(r.id)}/>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// ─── Right Run Config Panel ───────────────────────────────────────────────────
function SceneRunConfig({scene,onChange}:{scene:Scene;onChange:(s:Scene)=>void}){
  const[saveState,setSaveState]=useState<"idle"|"saving"|"saved"|"error">("idle");
  const saveScene=()=>{
    setSaveState("saving");
    setTimeout(()=>{
      const ok=Math.random()>.1;
      setSaveState(ok?"saved":"error");
      if(ok)setTimeout(()=>setSaveState("idle"),1800);
    },900);
  };
  return(
    <div className="flex-shrink-0 overflow-y-auto flex flex-col gap-0"
      style={{width:220,borderLeft:`1px solid ${T.border}`,backgroundColor:"#FAFBFE"}}>
      {/* Env + buttons */}
      <div className="p-3 space-y-2" style={{borderBottom:`1px solid ${T.border}`}}>
        <div className="flex items-center gap-1.5">
          <select value={scene.env} onChange={e=>onChange({...scene,env:e.target.value})}
            className="flex-1 h-7 px-2 border rounded-lg text-[12px] outline-none bg-white"
            style={{borderColor:T.border,color:T.t1}}>
            {ENVS.map(e=><option key={e}>{e}</option>)}
          </select>
          <button className="w-7 h-7 flex items-center justify-center rounded-lg border bg-white" style={{borderColor:T.border}}>
            <Settings size={12} style={{color:T.t3}}/>
          </button>
        </div>
        <div className="flex gap-2">
          <button className="flex-1 h-8 rounded-lg text-[12px] font-semibold text-white flex items-center justify-center gap-1.5"
            style={{backgroundColor:T.primary}}>
            <Play size={12}/>运行
          </button>
          <button onClick={saveScene} disabled={saveState==="saving"} className="flex-1 h-8 rounded-lg text-[12px] font-medium flex items-center justify-center gap-1.5 border bg-white"
            style={{borderColor:saveState==="error"?T.danger:saveState==="saved"?T.success:T.border,color:saveState==="error"?T.danger:saveState==="saved"?T.success:T.t2}}>
            {saveState==="saving"?<RefreshCw size={12} className="animate-spin"/>:saveState==="saved"?<CheckCircle size={12}/>:saveState==="error"?<AlertCircle size={12}/>:<Save size={12}/>}
            {saveState==="saving"?"保存中":saveState==="saved"?"已保存":saveState==="error"?"重试":"保存"}
          </button>
        </div>
        {saveState==="error"&&<p className="text-[10px]" style={{color:T.danger}}>保存场景失败，请重新保存。</p>}
      </div>
      {/* Config fields */}
      <div className="p-3 space-y-3 text-[12px]">
        {/* Module */}
        <div>
          <p className="font-medium mb-1" style={{color:T.t2}}>
            <span style={{color:T.danger}}>*</span> 所属模块
          </p>
          <select value={scene.module} onChange={e=>onChange({...scene,module:e.target.value})}
            className="w-full h-7 px-2 border rounded-lg text-[12px] outline-none bg-white"
            style={{borderColor:T.border,color:T.t1}}>
            {MODULES.filter(m=>m!=="全部").map(m=><option key={m}>{m}</option>)}
          </select>
        </div>
        {/* Test data */}
        <div>
          <p className="font-medium mb-1" style={{color:T.t2}}>测试数据</p>
          <select value={scene.testData||"不使用测试数据"} onChange={e=>onChange({...scene,testData:e.target.value==="不使用测试数据"?null:e.target.value})}
            className="w-full h-7 px-2 border rounded-lg text-[12px] outline-none bg-white"
            style={{borderColor:T.border,color:T.t1}}>
            {["不使用测试数据","注册测试数据集","订单压测数据集"].map(d=><option key={d}>{d}</option>)}
          </select>
        </div>
        {/* Iterations + threads */}
        <div className="flex gap-2">
          <div className="flex-1">
            <p className="font-medium mb-1" style={{color:T.t2}}>循环次数</p>
            <NumInp value={scene.iterations} onChange={v=>onChange({...scene,iterations:v})} max={999}/>
          </div>
          <div className="flex-1">
            <p className="font-medium mb-1" style={{color:T.t2}}>线程数</p>
            <NumInp value={scene.threads} onChange={v=>onChange({...scene,threads:v})} max={99}/>
          </div>
        </div>
        {/* Run location */}
        <div>
          <p className="font-medium mb-1" style={{color:T.t2}}>运行于</p>
          <select value={scene.runLocation==="server"?"服务端执行":"本地执行器"}
            onChange={e=>onChange({...scene,runLocation:e.target.value.includes("服务端")?"server":"runner"})}
            className="w-full h-7 px-2 border rounded-lg text-[12px] outline-none bg-white"
            style={{borderColor:T.border,color:T.t1}}>
            <option>服务端执行</option>
            <option>本地执行器</option>
          </select>
        </div>
        {/* Runner picker */}
        {scene.runLocation==="runner"&&(
          <div>
            <p className="font-medium mb-1" style={{color:T.t2}}>选择 Runner</p>
            <select value={scene.runnerId||RUNNERS[0].id} onChange={e=>onChange({...scene,runnerId:e.target.value})}
              className="w-full h-7 px-2 border rounded-lg text-[12px] outline-none bg-white"
              style={{borderColor:T.border,color:T.t1}}>
              {RUNNERS.map(r=><option key={r.id} value={r.id}>{r.name} ({r.status})</option>)}
            </select>
          </div>
        )}
        {/* Variable set */}
        <div>
          <p className="font-medium mb-1" style={{color:T.t2}}>变量集</p>
          <select value={scene.variableSet||"请选择变量集"}
            onChange={e=>onChange({...scene,variableSet:e.target.value==="请选择变量集"?null:e.target.value})}
            className="w-full h-7 px-2 border rounded-lg text-[12px] outline-none bg-white"
            style={{borderColor:T.border,color:T.t1}}>
            <option>请选择变量集</option>
            {VARIABLE_SETS.map(v=><option key={v}>{v}</option>)}
          </select>
        </div>
        {/* Tags */}
        <div>
          <p className="font-medium mb-1.5" style={{color:T.t2}}>标签</p>
          <div className="flex flex-wrap gap-1">
            {scene.tags.map(tag=>(
              <span key={tag} className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full text-[11px]"
                style={{backgroundColor:"#E8F3FF",color:T.primary}}>
                {tag}
                <button onClick={()=>onChange({...scene,tags:scene.tags.filter(t=>t!==tag)})} className="hover:opacity-70">
                  <X size={9}/>
                </button>
              </span>
            ))}
            <button className="text-[11px]" style={{color:T.t3}}>+ 添加</button>
          </div>
        </div>
      </div>
      {/* Last run */}
      {scene.lastRun&&(
        <div className="p-3 mt-auto" style={{borderTop:`1px solid ${T.border}`}}>
          <p className="text-[11px] font-medium mb-1" style={{color:T.t3}}>上次运行</p>
          <StatusDot status={scene.lastResult}/>
          <p className="text-[10px] mt-0.5" style={{color:T.t4}}>{scene.lastRun}</p>
        </div>
      )}
    </div>
  );
}

// ─── Scene Editor (step orchestration) ───────────────────────────────────────
function SceneEditor({scene,onChange}:{scene:Scene;onChange:(s:Scene)=>void}){
  const[subTab,setSubTab]=useState<"steps"|"data"|"settings"|"history">("steps");
  const[editingName,setEditingName]=useState(false);
  const[nameVal,setNameVal]=useState(scene.name);
  const[showAddStep,setShowAddStep]=useState(false);
  const[resourcePicker,setResourcePicker]=useState<"api"|"case"|"scene"|null>(null);
  const[configStep,setConfigStep]=useState<{step:Step;isNew:boolean}|null>(null);
  const[deleteTarget,setDeleteTarget]=useState<Step|null>(null);
  const[historyDetail,setHistoryDetail]=useState<string|null>(null);

  const flatSteps=scene.steps;

  const addStep=(type:StepType)=>{
    setConfigStep({step:createStepDraft(type),isNew:true});
  };

  const deleteStep=(id:string)=>{
    onChange({...scene,steps:scene.steps.filter(s=>s.id!==id)});
  };

  const toggleStep=(id:string)=>{
    onChange({...scene,steps:scene.steps.map(s=>s.id===id?{...s,enabled:!s.enabled}:s)});
  };

  const moveStep=(id:string,dir:-1|1)=>{
    const arr=[...scene.steps];
    const i=arr.findIndex(s=>s.id===id);
    if(i+dir<0||i+dir>=arr.length)return;
    [arr[i],arr[i+dir]]=[arr[i+dir],arr[i]];
    onChange({...scene,steps:arr});
  };

  const subTabs=[{k:"steps",l:`步骤 (${flatSteps.length})`},{k:"data",l:"测试数据"},{k:"settings",l:"设置"},{k:"history",l:"运行历史"}] as const;

  return(
    <div className="flex-1 flex overflow-hidden">
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Sub-tab bar */}
        <div className="flex items-center flex-shrink-0 px-4" style={{borderBottom:`1px solid ${T.border}`,height:38,backgroundColor:"#fff"}}>
          {subTabs.map(({k,l})=>(
            <button key={k} onClick={()=>setSubTab(k)}
              className="h-full px-4 text-[12px] font-medium border-b-2 transition-colors"
              style={{borderBottomColor:subTab===k?T.primary:"transparent",color:subTab===k?T.primary:T.t3}}>
              {l}
            </button>
          ))}
        </div>

        {subTab==="steps"&&(
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Scene info bar */}
            <div className="flex-shrink-0 px-4 py-3" style={{borderBottom:`1px solid ${T.border}`,backgroundColor:"#FAFBFE"}}>
              <div className="flex items-center gap-2 mb-1.5">
                {/* Priority dropdown */}
                <select value={scene.priority} onChange={e=>onChange({...scene,priority:e.target.value as Priority})}
                  className="h-6 px-2 rounded text-[11px] font-bold border outline-none"
                  style={{backgroundColor:PRIORITY_STYLE[scene.priority].bg,color:PRIORITY_STYLE[scene.priority].color,borderColor:PRIORITY_STYLE[scene.priority].color}}>
                  {(["P0","P1","P2","P3"] as Priority[]).map(p=><option key={p}>{p}</option>)}
                </select>
                {/* Name */}
                {editingName
                  ? <input autoFocus value={nameVal} onChange={e=>setNameVal(e.target.value)}
                      onBlur={()=>{onChange({...scene,name:nameVal});setEditingName(false);}}
                      onKeyDown={e=>{if(e.key==="Enter"){onChange({...scene,name:nameVal});setEditingName(false);}}}
                      className="text-[14px] font-semibold outline-none border-b px-1"
                      style={{color:T.t1,borderColor:T.primary}}/>
                  : <span className="text-[14px] font-semibold flex items-center gap-1.5 cursor-pointer" style={{color:T.t1}}
                      onClick={()=>setEditingName(true)}>
                      {scene.name}<Edit2 size={12} style={{color:T.t3}}/>
                    </span>
                }
              </div>
              {scene.desc&&<p className="text-[12px] mb-1" style={{color:T.t3}}>{scene.desc}</p>}
              <p className="text-[11px]" style={{color:T.t4}}>
                X-MAN · 更新于 2026-07-14 · {scene.module}
              </p>
            </div>
            {/* Steps header */}
            <div className="flex items-center justify-between px-4 py-2 flex-shrink-0" style={{borderBottom:`1px solid ${T.border}`}}>
              <p className="text-[12px]" style={{color:T.t2}}>共 <strong>{flatSteps.length}</strong> 个步骤</p>
              <div className="flex items-center gap-2">
                <Btn small icon={Plus} onClick={()=>setShowAddStep(true)}>添加步骤</Btn>
              </div>
            </div>
            {/* Step list */}
            <div className="flex-1 overflow-y-auto py-2 px-3" style={{backgroundColor:"#FAFBFE"}}>
              {flatSteps.length===0
                ? (
                  <div className="flex flex-col items-center justify-center py-16" style={{color:T.t3}}>
                    <Layers size={32} style={{color:T.t4,marginBottom:8}}/>
                    <p className="text-[13px] mb-3">还没有步骤，点击添加开始编排</p>
                    <Btn small icon={Plus} onClick={()=>setShowAddStep(true)}>添加步骤</Btn>
                  </div>
                )
                : flatSteps.map((step,i)=>(
                  <div key={step.id} className="mb-1 rounded-lg border overflow-hidden" style={{borderColor:T.border}}>
                    <StepRow
                      step={step} index={i} total={flatSteps.length}
                      onToggle={()=>toggleStep(step.id)}
                      onDelete={()=>setDeleteTarget(step)}
                      onMoveUp={()=>moveStep(step.id,-1)}
                      onMoveDown={()=>moveStep(step.id,1)}
                      onCopy={()=>{
                        const copy:Step={...step,id:`st${Date.now()}`,name:step.name+" (副本)"};
                        const arr=[...scene.steps];arr.splice(i+1,0,copy);
                        onChange({...scene,steps:arr});
                      }}
                      onConfig={target=>setConfigStep({step:target,isNew:false})}
                      onUpdateChildren={(children)=>onChange({...scene,steps:scene.steps.map(s=>s.id===step.id?{...s,children}:s)})}
                    />
                  </div>
                ))
              }
            </div>
          </div>
        )}

        {subTab==="data"&&<TestDataTab/>}
        {subTab==="settings"&&<SceneSettingsTab/>}
        {subTab==="history"&&<SceneHistoryTab onOpenDetail={setHistoryDetail}/>}
      </div>

      {/* Right config panel */}
      <SceneRunConfig scene={scene} onChange={onChange}/>

      {/* Dialogs */}
      {showAddStep&&(
        <AddStepDialog
          onAdd={addStep}
          onSelectResource={setResourcePicker}
          onClose={()=>setShowAddStep(false)}
        />
      )}
      {resourcePicker&&(
        <ResourcePickerDialog
          resourceType={resourcePicker}
          currentSceneId={scene.id}
          onClose={steps=>{
            if(steps.length>0)onChange({...scene,steps:[...scene.steps,...steps]});
            setResourcePicker(null);
          }}
        />
      )}
      {configStep&&(
        <StepConfigDrawer
          key={configStep.step.id}
          step={configStep.step}
          isNew={configStep.isNew}
          currentSceneId={scene.id}
          onSave={saved=>{
            if(configStep.isNew)onChange({...scene,steps:[...scene.steps,saved]});
            else onChange({...scene,steps:updateStepTree(scene.steps,saved)});
            setConfigStep(null);
          }}
          onClose={()=>setConfigStep(null)}
        />
      )}
      {deleteTarget&&(
        <div className="fixed inset-0 z-[120] flex items-center justify-center" style={{background:"rgba(29,33,41,.48)"}}>
          <div className="bg-white rounded-2xl shadow-2xl p-5" style={{width:420}}>
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{background:"#FFF0F0"}}><AlertTriangle size={17} style={{color:T.danger}}/></div>
              <div>
                <h4 className="text-[14px] font-semibold" style={{color:T.t1}}>删除“{deleteTarget.name}”？</h4>
                <p className="text-[12px] mt-1 leading-5" style={{color:T.t3}}>
                  {deleteTarget.children?.length
                    ? `该控制步骤包含 ${deleteTarget.children.length} 个子步骤，删除后将一并移除。`
                    : "删除后该步骤将从当前场景草稿中移除。"}
                </p>
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-5">
              <Btn ghost onClick={()=>setDeleteTarget(null)}>取消</Btn>
              <Btn danger onClick={()=>{deleteStep(deleteTarget.id);setDeleteTarget(null);}}>确认删除</Btn>
            </div>
          </div>
        </div>
      )}
      {historyDetail&&<SceneResultDrawer runId={historyDetail} history={MOCK_SCENE_HISTORY} onClose={()=>setHistoryDetail(null)}/>}
    </div>
  );
}

// ─── Scene List Page ──────────────────────────────────────────────────────────
function SceneListPage({scenes,onOpen,onCreate}:{scenes:Scene[];onOpen:(id:string)=>void;onCreate:()=>void}){
  const[search,setSearch]=useState("");
  const[filterModule,setFilterModule]=useState("全部");
  const[filterStatus,setFilterStatus]=useState("全部");
  const filtered=scenes.filter(s=>{
    if(search&&!s.name.toLowerCase().includes(search.toLowerCase()))return false;
    if(filterModule!=="全部"&&s.module!==filterModule)return false;
    if(filterStatus!=="全部"&&(filterStatus==="进行中"?s.status!=="active":s.status==="active"))return false;
    return true;
  });
  return(
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Filter bar */}
      <div className="flex items-center gap-2 px-4 py-3 flex-shrink-0" style={{borderBottom:`1px solid ${T.border}`}}>
        <div className="relative">
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="搜索场景名称"
            className="h-8 pl-8 pr-3 border rounded-lg text-[12px] outline-none"
            style={{borderColor:T.border,color:T.t1,width:220}}/>
          <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2" style={{color:T.t3}}/>
        </div>
        <Sel value={filterModule} onChange={setFilterModule} options={MODULES} width={120}/>
        <Sel value={filterStatus} onChange={setFilterStatus} options={["全部","进行中","未激活"]} width={100}/>
        <div className="flex-1"/>
        <Btn icon={Plus} onClick={onCreate}>新建场景</Btn>
      </div>
      {/* Table */}
      <div className="flex-1 overflow-y-auto">
        <table className="w-full text-[12px]">
          <thead style={{position:"sticky",top:0,zIndex:1}}>
            <tr style={{backgroundColor:T.bg,borderBottom:`1px solid ${T.border}`}}>
              {["ID","场景名称","优先级","所属模块","步骤数","最近结果","操作"].map((h,i)=>(
                <th key={h} className={`px-4 py-2.5 text-left font-medium ${i===6?"text-right":""}`} style={{color:T.t3}}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((s,i)=>(
              <tr key={s.id} className="group hover:bg-blue-50/30 transition-colors"
                style={{borderBottom:`1px solid ${T.border}`,backgroundColor:i%2===0?"#fff":"#FAFBFE"}}>
                <td className="px-4 py-3 font-mono" style={{color:T.t3}}>{s.id}</td>
                <td className="px-4 py-3">
                  <button onClick={()=>onOpen(s.id)} className="font-medium hover:underline text-left" style={{color:T.primary}}>{s.name}</button>
                  {s.tags.length>0&&(
                    <div className="flex gap-1 mt-1">
                      {s.tags.slice(0,3).map(tag=>(
                        <span key={tag} className="text-[10px] px-1.5 py-0.5 rounded" style={{backgroundColor:"#F2F3F5",color:T.t3}}>{tag}</span>
                      ))}
                    </div>
                  )}
                </td>
                <td className="px-4 py-3"><PTag p={s.priority}/></td>
                <td className="px-4 py-3" style={{color:T.t2}}>{s.module}</td>
                <td className="px-4 py-3" style={{color:T.t2}}>{s.steps.length} 个</td>
                <td className="px-4 py-3"><StatusDot status={s.lastResult}/></td>
                <td className="px-4 py-3">
                  <div className="flex items-center justify-end gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                    <IBtn icon={Edit2} label="编辑" onClick={()=>onOpen(s.id)}/>
                    <IBtn icon={Play} label="运行"/>
                    <IBtn icon={Copy} label="复制"/>
                    <IBtn icon={Trash2} label="删除" danger/>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length===0&&(
          <div className="flex flex-col items-center justify-center py-16" style={{color:T.t3}}>
            <p className="text-[13px]">暂无符合条件的场景</p>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Scene Management (multi-tab) ─────────────────────────────────────────────
export function SceneManagement(){
  const[scenes,setScenes]=useState<Scene[]>(INIT_SCENES);
  const[openIds,setOpenIds]=useState<string[]>([]);
  const[activeTab,setActiveTab]=useState<string>("list");

  const openScene=(id:string)=>{
    if(!openIds.includes(id))setOpenIds(p=>[...p,id]);
    setActiveTab(id);
  };
  const closeScene=(id:string,e:React.MouseEvent)=>{
    e.stopPropagation();
    const next=openIds.filter(x=>x!==id);
    setOpenIds(next);
    if(activeTab===id)setActiveTab(next[next.length-1]??"list");
  };
  const createScene=()=>{
    const id=`new-${Date.now()}`;
    const newS:Scene={
      id,name:`新建场景 ${scenes.length+1}`,module:"获客中心",priority:"P2",
      status:"active",desc:"",tags:[],env:"测试环境",testData:null,
      iterations:1,threads:1,runLocation:"server",variableSet:null,
      steps:[],lastRun:null,lastResult:null,
    };
    setScenes(p=>[...p,newS]);
    openScene(id);
  };

  return(
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Multi-tab bar */}
      <div className="flex items-center flex-shrink-0 border-b px-2 gap-0" style={{height:38,borderColor:T.border,backgroundColor:"#fff"}}>
        {/* List tab */}
        <button onClick={()=>setActiveTab("list")}
          className="px-3 py-1 text-[12px] font-medium rounded-md mr-1 transition-colors flex-shrink-0"
          style={{backgroundColor:activeTab==="list"?"#E8F3FF":"transparent",color:activeTab==="list"?T.primary:T.t3}}>
          全部场景
        </button>
        <div className="w-px h-4 flex-shrink-0" style={{backgroundColor:T.border}}/>
        {/* Open scene tabs */}
        <div className="flex-1 flex items-center gap-0.5 overflow-x-auto px-1">
          {openIds.map(id=>{
            const s=scenes.find(x=>x.id===id);
            const isActive=activeTab===id;
            return(
              <button key={id} onClick={()=>setActiveTab(id)}
                className="flex items-center gap-1.5 px-3 py-1 rounded-md text-[12px] font-medium whitespace-nowrap flex-shrink-0 transition-colors group/tab"
                style={{backgroundColor:isActive?"#E8F3FF":"transparent",color:isActive?T.primary:T.t3}}>
                <span className="max-w-[120px] truncate">{s?.name??"未命名场景"}</span>
                <span onClick={e=>closeScene(id,e)}
                  className="w-4 h-4 flex items-center justify-center rounded hover:bg-blue-200/60 opacity-0 group-hover/tab:opacity-100 transition-opacity">
                  <X size={10}/>
                </span>
              </button>
            );
          })}
        </div>
        {/* New tab button */}
        <button onClick={createScene}
          className="w-7 h-7 flex-shrink-0 flex items-center justify-center rounded-md hover:bg-gray-100 transition-colors">
          <Plus size={14} style={{color:T.t3}}/>
        </button>
        <span className="text-[11px] px-2 flex-shrink-0" style={{color:T.t4}}>···</span>
      </div>
      {/* Content */}
      {activeTab==="list"&&<SceneListPage scenes={scenes} onOpen={openScene} onCreate={createScene}/>}
      {openIds.map(id=>(
        activeTab===id&&(
          <SceneEditor key={id}
            scene={scenes.find(s=>s.id===id)!}
            onChange={updated=>setScenes(p=>p.map(s=>s.id===id?updated:s))}/>
        )
      ))}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════════
// SUITE MANAGEMENT
// ════════════════════════════════════════════════════════════════════════════════

// ─── Suite Run Config ─────────────────────────────────────────────────────────
function SuiteRunConfig({suite,onChange}:{suite:Suite;onChange:(s:Suite)=>void}){
  return(
    <div className="flex-shrink-0 overflow-y-auto" style={{width:220,borderLeft:`1px solid ${T.border}`,backgroundColor:"#FAFBFE"}}>
      <div className="p-3 space-y-2" style={{borderBottom:`1px solid ${T.border}`}}>
        <select value={suite.env} onChange={e=>onChange({...suite,env:e.target.value})}
          className="w-full h-7 px-2 border rounded-lg text-[12px] outline-none bg-white"
          style={{borderColor:T.border,color:T.t1}}>
          {ENVS.map(e=><option key={e}>{e}</option>)}
        </select>
        <div className="flex gap-2">
          <button className="flex-1 h-8 rounded-lg text-[12px] font-semibold text-white flex items-center justify-center gap-1.5"
            style={{backgroundColor:T.primary}}>
            <Play size={12}/>运行
          </button>
          <button className="flex-1 h-8 rounded-lg text-[12px] font-medium flex items-center justify-center gap-1.5 border bg-white"
            style={{borderColor:T.border,color:T.t2}}>
            <Save size={12}/>保存
          </button>
        </div>
      </div>
      <div className="p-3 space-y-3 text-[12px]">
        {/* Module */}
        <div>
          <p className="font-medium mb-1" style={{color:T.t2}}><span style={{color:T.danger}}>*</span> 所属模块</p>
          <select value={suite.module} onChange={e=>onChange({...suite,module:e.target.value})}
            className="w-full h-7 px-2 border rounded-lg text-[12px] outline-none bg-white"
            style={{borderColor:T.border,color:T.t1}}>
            {MODULES.map(m=><option key={m}>{m}</option>)}
          </select>
        </div>
        {/* Run mode */}
        <div>
          <p className="font-medium mb-1.5" style={{color:T.t2}}>运行模式</p>
          <div className="flex gap-3">
            {(["serial","parallel"] as const).map(m=>(
              <label key={m} className="flex items-center gap-1.5 cursor-pointer text-[12px]" style={{color:T.t1}}>
                <input type="radio" name="runMode" checked={suite.runMode===m} onChange={()=>onChange({...suite,runMode:m})}
                  className="accent-blue-600"/>
                {m==="serial"?"串行":"并行"}
              </label>
            ))}
          </div>
        </div>
        {/* Run location */}
        <div>
          <p className="font-medium mb-1" style={{color:T.t2}}>运行于</p>
          <select value={suite.runLocation==="server"?"服务端执行":"本地执行器"}
            onChange={e=>onChange({...suite,runLocation:e.target.value.includes("服务端")?"server":"runner"})}
            className="w-full h-7 px-2 border rounded-lg text-[12px] outline-none bg-white"
            style={{borderColor:T.border,color:T.t1}}>
            <option>服务端执行</option>
            <option>本地执行器</option>
          </select>
        </div>
        {suite.runLocation==="runner"&&(
          <div className="p-2.5 rounded-xl border" style={{borderColor:T.border}}>
            {RUNNERS.map(r=>(
              <div key={r.id} className="flex items-center gap-2 py-1">
                <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{backgroundColor:r.status==="在线"?T.success:T.t4}}/>
                <div className="flex-1">
                  <p className="text-[11px] font-medium" style={{color:T.t1}}>{r.name}</p>
                  <p className="text-[10px]" style={{color:T.t3}}>{r.id} · {r.status}</p>
                </div>
                <input type="radio" name="runnerId" defaultChecked={r.status==="在线"} className="accent-blue-600"/>
              </div>
            ))}
          </div>
        )}
        {/* Notify */}
        <div className="flex items-center justify-between">
          <p className="font-medium" style={{color:T.t2}}>运行通知</p>
          <Toggle on={suite.notify} onToggle={()=>onChange({...suite,notify:!suite.notify})}/>
        </div>
        {/* Last run */}
        {suite.lastRun&&(
          <div className="pt-3" style={{borderTop:`1px solid ${T.border}`}}>
            <p className="font-medium mb-1" style={{color:T.t2}}>上次运行结果</p>
            <StatusDot status={suite.lastResult}/>
            <p className="text-[10px] mt-0.5" style={{color:T.t4}}>{suite.lastRun}</p>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Add Case Dialog ──────────────────────────────────────────────────────────
function AddCaseDialog({onClose,existing}:{onClose:(added:string[])=>void;existing:Set<string>}){
  const[selected,setSelected]=useState<Set<string>>(new Set());
  const[search,setSearch]=useState("");
  const rows=MOCK_CANDIDATE_CASES.filter(c=>!search||c.name.toLowerCase().includes(search.toLowerCase()));
  const toggle=(id:string)=>{if(existing.has(id))return;const n=new Set(selected);n.has(id)?n.delete(id):n.add(id);setSelected(n);};
  return(
    <Modal title="添加接口用例" onClose={()=>onClose([])} width={680}>
      <div className="flex flex-col" style={{height:480}}>
        <div className="flex items-center gap-2 px-4 py-2.5 flex-shrink-0" style={{borderBottom:`1px solid ${T.border}`}}>
          <select className="h-7 px-2 border rounded-lg text-[12px] outline-none" style={{borderColor:T.border,width:120}}><option>X-MAN</option></select>
          <select className="h-7 px-2 border rounded-lg text-[12px] outline-none" style={{borderColor:T.border,width:80}}><option>HTTP</option></select>
          <div className="relative flex-1">
            <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="搜索用例名称"
              className="w-full h-7 pl-7 pr-3 border rounded-lg text-[12px] outline-none"
              style={{borderColor:T.border}}/>
            <Search size={12} className="absolute left-2 top-1/2 -translate-y-1/2" style={{color:T.t3}}/>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          <table className="w-full text-[12px]">
            <thead style={{position:"sticky",top:0}}>
              <tr style={{backgroundColor:T.bg,borderBottom:`1px solid ${T.border}`}}>
                <th className="px-4 py-2 w-8"><input type="checkbox" className="rounded"/></th>
                <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>ID</th>
                <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>用例名称</th>
                <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>方法</th>
                <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>请求路径</th>
                <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>所属接口</th>
                <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>运行状态</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((c,i)=>{
                const inSuite=existing.has(c.id);
                return(
                  <tr key={c.id} style={{borderBottom:`1px solid ${T.border}`,opacity:inSuite?.5:1,backgroundColor:i%2===0?"transparent":T.bg+"80"}}>
                    <td className="px-4 py-2.5">
                      {inSuite
                        ? <span className="text-[10px] px-1.5 py-0.5 rounded" style={{backgroundColor:"#F2F3F5",color:T.t3}}>已在套件</span>
                        : <input type="checkbox" checked={selected.has(c.id)} onChange={()=>toggle(c.id)} className="rounded"/>
                      }
                    </td>
                    <td className="px-2 py-2.5 font-mono" style={{color:T.t3}}>{c.id}</td>
                    <td className="px-2 py-2.5 font-medium" style={{color:T.t1}}>{c.name}</td>
                    <td className="px-2 py-2.5"><MethodTag m={c.method}/></td>
                    <td className="px-2 py-2.5 font-mono text-[11px]" style={{color:T.t2}}>{c.path}</td>
                    <td className="px-2 py-2.5" style={{color:T.t3}}>{c.api}</td>
                    <td className="px-2 py-2.5"><StatusDot status={null}/></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between px-4 py-3 flex-shrink-0" style={{borderTop:`1px solid ${T.border}`}}>
          <p className="text-[12px]" style={{color:T.t3}}>
            已选 <strong style={{color:T.primary}}>{selected.size}</strong> · 当前页 {rows.length} · 共 {MOCK_CANDIDATE_CASES.length}
          </p>
          <div className="flex gap-2">
            <Btn ghost onClick={()=>onClose([])}>取消</Btn>
            <Btn onClick={()=>onClose([...selected])} disabled={selected.size===0}>添加 {selected.size>0?`(${selected.size})`:""}</Btn>
          </div>
        </div>
      </div>
    </Modal>
  );
}

// ─── Add Scene Dialog ─────────────────────────────────────────────────────────
function AddSceneDialog({onClose,existing}:{onClose:(added:string[])=>void;existing:Set<string>}){
  const[selected,setSelected]=useState<Set<string>>(new Set());
  const[search,setSearch]=useState("");
  const rows=MOCK_CANDIDATE_SCENES.filter(s=>!search||s.name.toLowerCase().includes(search.toLowerCase()));
  const toggle=(id:string)=>{if(existing.has(id))return;const n=new Set(selected);n.has(id)?n.delete(id):n.add(id);setSelected(n);};
  return(
    <Modal title="添加场景" onClose={()=>onClose([])} width={680}>
      <div className="flex flex-col" style={{height:440}}>
        <div className="flex items-center gap-2 px-4 py-2.5 flex-shrink-0" style={{borderBottom:`1px solid ${T.border}`}}>
          <select className="h-7 px-2 border rounded-lg text-[12px] outline-none" style={{borderColor:T.border,width:120}}><option>X-MAN</option></select>
          <div className="relative flex-1">
            <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="搜索场景名称"
              className="w-full h-7 pl-7 pr-3 border rounded-lg text-[12px] outline-none"
              style={{borderColor:T.border}}/>
            <Search size={12} className="absolute left-2 top-1/2 -translate-y-1/2" style={{color:T.t3}}/>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          <table className="w-full text-[12px]">
            <thead style={{position:"sticky",top:0}}>
              <tr style={{backgroundColor:T.bg,borderBottom:`1px solid ${T.border}`}}>
                <th className="px-4 py-2 w-8"><input type="checkbox" className="rounded"/></th>
                <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>ID</th>
                <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>场景名称</th>
                <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>所属模块</th>
                <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>步骤数</th>
                <th className="px-2 py-2 text-left font-medium" style={{color:T.t3}}>状态</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((s,i)=>{
                const inSuite=existing.has(s.id);
                return(
                  <tr key={s.id} style={{borderBottom:`1px solid ${T.border}`,opacity:inSuite?.5:1,backgroundColor:i%2===0?"transparent":T.bg+"80"}}>
                    <td className="px-4 py-2.5">
                      {inSuite
                        ? <span className="text-[10px] px-1.5 py-0.5 rounded" style={{backgroundColor:"#F2F3F5",color:T.t3}}>已在套件</span>
                        : <input type="checkbox" checked={selected.has(s.id)} onChange={()=>toggle(s.id)} className="rounded"/>
                      }
                    </td>
                    <td className="px-2 py-2.5 font-mono" style={{color:T.t3}}>{s.id}</td>
                    <td className="px-2 py-2.5 font-medium" style={{color:T.t1}}>{s.name}</td>
                    <td className="px-2 py-2.5" style={{color:T.t3}}>{s.module}</td>
                    <td className="px-2 py-2.5" style={{color:T.t2}}>{s.steps} 个</td>
                    <td className="px-2 py-2.5"><StatusDot status={s.status==="active"?"pass":null}/></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between px-4 py-3 flex-shrink-0" style={{borderTop:`1px solid ${T.border}`}}>
          <p className="text-[12px]" style={{color:T.t3}}>
            已选 <strong style={{color:T.primary}}>{selected.size}</strong> · 当前页 {rows.length} · 共 {MOCK_CANDIDATE_SCENES.length}
          </p>
          <div className="flex gap-2">
            <Btn ghost onClick={()=>onClose([])}>取消</Btn>
            <Btn onClick={()=>onClose([...selected])} disabled={selected.size===0}>添加 {selected.size>0?`(${selected.size})`:""}</Btn>
          </div>
        </div>
      </div>
    </Modal>
  );
}

// ─── Suite Run Records ────────────────────────────────────────────────────────
const SUITE_STEP_NAMES=["发送验证码","注册账户","登录获取Token","查询用户(失败)"];
const SUITE_STEP_DURATIONS=[120,340,280,150];
function SuiteResultItem({item}:{item:{name:string;type:SuiteItemType;result:"pass"|"fail";steps:number;duration:string;fail:string}}){
  const[expanded,setExpanded]=useState(item.result==="fail");
  const[stepDetail,setStepDetail]=useState<StepDetailInfo|null>(null);
  return(
    <>
      <div className="rounded-xl border overflow-hidden" style={{borderColor:T.border}}>
        <div className="flex items-center gap-3 px-4 py-3 bg-white cursor-pointer" onClick={()=>setExpanded(p=>!p)}>
          {item.result==="pass"
            ?<CheckCircle size={16} style={{color:T.success,flexShrink:0}}/>
            :<XCircle size={16} style={{color:T.danger,flexShrink:0}}/>
          }
          <span className="text-[11px] px-1.5 py-0.5 rounded" style={{backgroundColor:item.type==="api"?"#E8F3FF":"#E8FFEA",color:item.type==="api"?T.primary:T.success}}>{item.type==="api"?"接口用例":"场景"}</span>
          <p className="flex-1 text-[13px] font-medium" style={{color:T.t1}}>{item.name}</p>
          <span className="text-[11px]" style={{color:T.t3}}>{item.steps} 步骤 · {item.duration}</span>
          {item.fail&&<AlertCircle size={14} style={{color:T.danger}}/>}
          {expanded?<ChevronUp size={14} style={{color:T.t3}}/>:<ChevronDown size={14} style={{color:T.t3}}/>}
        </div>
        {expanded&&(
          <div style={{backgroundColor:T.bg,borderTop:`1px solid ${T.border}`}}>
            {item.fail&&(
              <div className="px-4 py-2.5 flex items-start gap-2" style={{borderBottom:`1px solid ${T.border}`}}>
                <AlertCircle size={13} style={{color:T.danger,flexShrink:0,marginTop:1}}/>
                <p className="text-[12px]" style={{color:T.danger}}>{item.fail}</p>
              </div>
            )}
            {Array.from({length:Math.min(item.steps,4)}).map((_,si)=>{
              const isFail=si===3&&item.result==="fail";
              return(
                <div key={si} className="flex items-center gap-3 px-6 py-2" style={{borderBottom:`1px solid ${T.border}`}}>
                  {isFail
                    ?<XCircle size={12} style={{color:T.danger}}/>
                    :<CheckCircle size={12} style={{color:T.success}}/>
                  }
                  <span className="text-[11px] flex-1" style={{color:T.t2}}>步骤 {si+1} · {SUITE_STEP_NAMES[si]}</span>
                  <span className="text-[10px] font-mono" style={{color:isFail?T.danger:T.t3}}>{isFail?"404":200}</span>
                  <span className="text-[10px]" style={{color:T.t3}}>{SUITE_STEP_DURATIONS[si]}ms</span>
                  <IBtn icon={Eye} label="查看详情" onClick={()=>setStepDetail({name:SUITE_STEP_NAMES[si],status:isFail?"fail":"pass",duration:`${SUITE_STEP_DURATIONS[si]}ms`,index:si})}/>
                </div>
              );
            })}
          </div>
        )}
      </div>
      {stepDetail&&<StepDetailDrawer step={stepDetail} onClose={()=>setStepDetail(null)}/>}
    </>
  );
}

function SuiteRunRecordsTab({suiteId}:{suiteId:string}){
  const[selRecord,setSelRecord]=useState<RunRecord|null>(null);
  const records=MOCK_RUN_RECORDS;

  if(selRecord){
    return(
      <div className="flex-1 overflow-y-auto p-5">
        {/* Breadcrumb */}
        <button onClick={()=>setSelRecord(null)} className="flex items-center gap-1.5 mb-4 text-[12px]" style={{color:T.t3}}>
          <ChevronRight size={12} style={{transform:"rotate(180deg)"}}/>返回运行结果列表
        </button>
        {/* Summary cards */}
        <div className="grid grid-cols-4 gap-3 mb-5">
          {[
            {label:"通过",value:selRecord.pass,color:T.success},
            {label:"失败",value:selRecord.fail,color:T.danger},
            {label:"跳过",value:0,color:T.t3},
            {label:"耗时",value:selRecord.duration,color:T.primary},
          ].map(s=>(
            <div key={s.label} className="rounded-xl p-4 bg-white border" style={{borderColor:T.border}}>
              <p className="text-[11px]" style={{color:T.t3}}>{s.label}</p>
              <p className="text-[22px] font-bold mt-1" style={{color:s.color}}>{s.value}</p>
            </div>
          ))}
        </div>
        {/* Meta */}
        <div className="flex gap-4 mb-4 text-[12px]" style={{color:T.t3}}>
          {[["环境","测试环境"],["变量集","公共变量集"],["失败后继续","是"],["重试次数","0"]].map(([k,v])=>(
            <span key={k}><strong>{k}：</strong>{v}</span>
          ))}
        </div>
        {/* Items */}
        <div className="space-y-2">
          {[
            {name:"用户注册",type:"api" as SuiteItemType,result:"pass" as const,steps:3,duration:"1.2s",fail:""},
            {name:"产品管理-新增编辑删除闭环",type:"scene" as SuiteItemType,result:"fail" as const,steps:10,duration:"8.4s",fail:"步骤 4 断言失败：期望 200 实际 404"},
            {name:"创建订单",type:"api" as SuiteItemType,result:"pass" as const,steps:2,duration:"0.8s",fail:""},
          ].map((item,i)=>(
            <SuiteResultItem key={i} item={item}/>
          ))}
        </div>
      </div>
    );
  }

  return(
    <div className="flex-1 overflow-y-auto p-5">
      <div className="flex items-center justify-between mb-4">
        <p className="text-[13px] font-semibold" style={{color:T.t1}}>运行记录</p>
        <Btn ghost small icon={RefreshCw}>刷新</Btn>
      </div>
      <table className="w-full text-[12px]">
        <thead>
          <tr style={{backgroundColor:T.bg,borderBottom:`1px solid ${T.border}`}}>
            {["开始时间","环境","通过/总数","失败","耗时","执行人","状态","操作"].map((h,i)=>(
              <th key={h} className={`px-4 py-2.5 text-left font-medium ${i===7?"text-right":""}`} style={{color:T.t3}}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {records.map((r,i)=>(
            <tr key={r.id} className="hover:bg-blue-50/30" style={{borderBottom:`1px solid ${T.border}`,backgroundColor:i%2===0?"#fff":"#FAFBFE"}}>
              <td className="px-4 py-3 font-mono text-[11px]" style={{color:T.t2}}>{r.startTime}</td>
              <td className="px-4 py-3" style={{color:T.t2}}>{r.env}</td>
              <td className="px-4 py-3">
                <span className="font-bold" style={{color:T.success}}>{r.pass}</span>
                <span style={{color:T.t3}}> / {r.total}</span>
              </td>
              <td className="px-4 py-3">
                {r.fail>0?<span className="font-bold" style={{color:T.danger}}>{r.fail}</span>:<span style={{color:T.t4}}>0</span>}
              </td>
              <td className="px-4 py-3 font-mono text-[11px]" style={{color:T.t2}}>{r.duration}</td>
              <td className="px-4 py-3" style={{color:T.t2}}>{r.operator}</td>
              <td className="px-4 py-3"><StatusDot status={r.status==="running"?"running":r.status}/></td>
              <td className="px-4 py-3 text-right">
                <IBtn icon={Eye} label="查看详情" onClick={()=>setSelRecord(r)}/>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ─── Suite Editor ─────────────────────────────────────────────────────────────
function SuiteEditor({suite,onChange}:{suite:Suite;onChange:(s:Suite)=>void}){
  const[subTab,setSubTab]=useState<"arrange"|"results">("arrange");
  const[editingName,setEditingName]=useState(false);
  const[nameVal,setNameVal]=useState(suite.name);
  const[showAddCase,setShowAddCase]=useState(false);
  const[showAddScene,setShowAddScene]=useState(false);
  const existingIds=new Set(suite.items.map(i=>i.id));

  const moveItem=(idx:number,dir:-1|1)=>{
    const arr=[...suite.items];
    if(idx+dir<0||idx+dir>=arr.length)return;
    [arr[idx],arr[idx+dir]]=[arr[idx+dir],arr[idx]];
    onChange({...suite,items:arr});
  };
  const deleteItem=(id:string)=>onChange({...suite,items:suite.items.filter(i=>i.id!==id)});

  const subTabs=[
    {k:"arrange",l:`编排 (${suite.items.length})`},
    {k:"results",l:"运行结果"},
  ] as const;

  return(
    <div className="flex-1 flex overflow-hidden">
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Sub-tabs */}
        <div className="flex items-center flex-shrink-0 px-4" style={{borderBottom:`1px solid ${T.border}`,height:38,backgroundColor:"#fff"}}>
          {subTabs.map(({k,l})=>(
            <button key={k} onClick={()=>setSubTab(k)}
              className="h-full px-4 text-[12px] font-medium border-b-2 transition-colors"
              style={{borderBottomColor:subTab===k?T.primary:"transparent",color:subTab===k?T.primary:T.t3}}>
              {l}
            </button>
          ))}
        </div>

        {subTab==="arrange"&&(
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Suite info */}
            <div className="flex-shrink-0 px-4 py-3" style={{borderBottom:`1px solid ${T.border}`,backgroundColor:"#FAFBFE"}}>
              <div className="flex items-center gap-2 mb-1">
                <select value={suite.priority} onChange={e=>onChange({...suite,priority:e.target.value as Priority})}
                  className="h-6 px-2 rounded text-[11px] font-bold border outline-none"
                  style={{backgroundColor:PRIORITY_STYLE[suite.priority as Priority].bg,color:PRIORITY_STYLE[suite.priority as Priority].color,borderColor:PRIORITY_STYLE[suite.priority as Priority].color}}>
                  {["P0","P1","P2","P3"].map(p=><option key={p}>{p}</option>)}
                </select>
                {editingName
                  ? <input autoFocus value={nameVal} onChange={e=>setNameVal(e.target.value)}
                      onBlur={()=>{onChange({...suite,name:nameVal});setEditingName(false);}}
                      onKeyDown={e=>{if(e.key==="Enter"){onChange({...suite,name:nameVal});setEditingName(false);}}}
                      className="text-[14px] font-semibold outline-none border-b px-1"
                      style={{color:T.t1,borderColor:T.primary}}/>
                  : <span onClick={()=>setEditingName(true)} className="text-[14px] font-semibold flex items-center gap-1.5 cursor-pointer" style={{color:T.t1}}>
                      {suite.name}<Edit2 size={12} style={{color:T.t3}}/>
                    </span>
                }
              </div>
              {suite.desc&&<p className="text-[12px]" style={{color:T.t3}}>{suite.desc}</p>}
            </div>
            {/* Toolbar */}
            <div className="flex items-center justify-between px-4 py-2 flex-shrink-0" style={{borderBottom:`1px solid ${T.border}`}}>
              <p className="text-[12px]" style={{color:T.t2}}>共 <strong>{suite.items.length}</strong> 个编排项，执行顺序即保存顺序</p>
              <div className="flex gap-2">
                <Btn ghost small icon={FileText} onClick={()=>setShowAddCase(true)}>添加接口用例</Btn>
                <Btn ghost small icon={Layers} onClick={()=>setShowAddScene(true)}>添加场景</Btn>
              </div>
            </div>
            {/* Items */}
            <div className="flex-1 overflow-y-auto py-2 px-3" style={{backgroundColor:"#FAFBFE"}}>
              {suite.items.length===0
                ? (
                  <div className="flex flex-col items-center justify-center py-16" style={{color:T.t3}}>
                    <FileText size={32} style={{color:T.t4,marginBottom:8}}/>
                    <p className="text-[13px] mb-3">还没有编排项，添加接口用例或场景开始</p>
                    <div className="flex gap-2">
                      <Btn ghost small icon={FileText} onClick={()=>setShowAddCase(true)}>添加用例</Btn>
                      <Btn ghost small icon={Layers} onClick={()=>setShowAddScene(true)}>添加场景</Btn>
                    </div>
                  </div>
                )
                : suite.items.map((item,i)=>(
                  <div key={item.id} className="mb-1.5 flex items-center gap-2 px-3 py-3 rounded-xl border bg-white group hover:shadow-sm transition-shadow"
                    style={{borderColor:T.border}}>
                    <GripVertical size={14} className="opacity-30 cursor-grab group-hover:opacity-60 flex-shrink-0" style={{color:T.t3}}/>
                    <span className="w-5 text-center text-[11px] flex-shrink-0" style={{color:T.t4}}>{i+1}</span>
                    {/* Type badge */}
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold flex-shrink-0"
                      style={{backgroundColor:item.type==="api"?"#E8F3FF":"#E8FFEA",color:item.type==="api"?T.primary:T.success}}>
                      {item.type==="api"?"接口":"场景"}
                    </span>
                    {item.method&&<MethodTag m={item.method}/>}
                    <p className="flex-1 text-[13px] font-medium truncate" style={{color:T.t1}}>{item.name}</p>
                    {item.path&&<span className="text-[11px] font-mono" style={{color:T.t3}}>{item.path}</span>}
                    {item.desc&&<span className="text-[11px]" style={{color:T.t3}}>{item.desc}</span>}
                    <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                      <IBtn icon={ArrowUp} label="上移" onClick={()=>moveItem(i,-1)}/>
                      <IBtn icon={ArrowDown} label="下移" onClick={()=>moveItem(i,1)}/>
                      <IBtn icon={Trash2} label="移除" danger onClick={()=>deleteItem(item.id)}/>
                    </div>
                  </div>
                ))
              }
            </div>
          </div>
        )}

        {subTab==="results"&&<SuiteRunRecordsTab suiteId={suite.id}/>}
      </div>

      {/* Right config */}
      <SuiteRunConfig suite={suite} onChange={onChange}/>

      {showAddCase&&<AddCaseDialog existing={existingIds} onClose={ids=>{
        if(ids.length>0){
          const newItems:SuiteItem[]=MOCK_CANDIDATE_CASES
            .filter(c=>ids.includes(c.id))
            .map(c=>({id:c.id,type:"api" as SuiteItemType,name:c.name,method:c.method,path:c.path}));
          onChange({...suite,items:[...suite.items,...newItems]});
        }
        setShowAddCase(false);
      }}/>}
      {showAddScene&&<AddSceneDialog existing={existingIds} onClose={ids=>{
        if(ids.length>0){
          const newItems:SuiteItem[]=MOCK_CANDIDATE_SCENES
            .filter(s=>ids.includes(s.id))
            .map(s=>({id:s.id,type:"scene" as SuiteItemType,name:s.name,desc:`${s.steps} 个步骤`}));
          onChange({...suite,items:[...suite.items,...newItems]});
        }
        setShowAddScene(false);
      }}/>}
    </div>
  );
}

// ─── Suite List Page ──────────────────────────────────────────────────────────
function SuiteListPage({suites,onOpen,onCreate}:{suites:Suite[];onOpen:(id:string)=>void;onCreate:()=>void}){
  const[search,setSearch]=useState("");
  const filtered=suites.filter(s=>!search||s.name.toLowerCase().includes(search.toLowerCase()));
  return(
    <div className="flex-1 flex flex-col overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-3 flex-shrink-0" style={{borderBottom:`1px solid ${T.border}`}}>
        <div className="relative">
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="搜索套件名称"
            className="h-8 pl-8 pr-3 border rounded-lg text-[12px] outline-none"
            style={{borderColor:T.border,color:T.t1,width:220}}/>
          <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2" style={{color:T.t3}}/>
        </div>
        <Sel value="全部" onChange={()=>{}} options={MODULES} width={120}/>
        <div className="flex-1"/>
        <Btn icon={Plus} onClick={onCreate}>新建套件</Btn>
      </div>
      <div className="flex-1 overflow-y-auto">
        <table className="w-full text-[12px]">
          <thead style={{position:"sticky",top:0,zIndex:1}}>
            <tr style={{backgroundColor:T.bg,borderBottom:`1px solid ${T.border}`}}>
              {["套件名称","优先级","所属模块","编排项","最近结果","最近运行","操作"].map((h,i)=>(
                <th key={h} className={`px-4 py-2.5 text-left font-medium ${i===6?"text-right":""}`} style={{color:T.t3}}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((s,i)=>(
              <tr key={s.id} className="group hover:bg-blue-50/30"
                style={{borderBottom:`1px solid ${T.border}`,backgroundColor:i%2===0?"#fff":"#FAFBFE"}}>
                <td className="px-4 py-3">
                  <button onClick={()=>onOpen(s.id)} className="font-semibold hover:underline text-left" style={{color:T.primary}}>{s.name}</button>
                  <p className="text-[11px] mt-0.5" style={{color:T.t3}}>{s.desc}</p>
                </td>
                <td className="px-4 py-3"><PTag p={s.priority as Priority}/></td>
                <td className="px-4 py-3" style={{color:T.t2}}>{s.module}</td>
                <td className="px-4 py-3" style={{color:T.t2}}>{s.items.length} 项</td>
                <td className="px-4 py-3"><StatusDot status={s.lastResult}/></td>
                <td className="px-4 py-3 font-mono text-[11px]" style={{color:T.t3}}>{s.lastRun??"-"}</td>
                <td className="px-4 py-3 text-right">
                  <div className="flex items-center justify-end gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                    <IBtn icon={Edit2} label="编辑" onClick={()=>onOpen(s.id)}/>
                    <IBtn icon={Play} label="运行"/>
                    <IBtn icon={Trash2} label="删除" danger/>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── Suite Management (multi-tab) ─────────────────────────────────────────────
export function SuiteManagement(){
  const[suites,setSuites]=useState<Suite[]>(INIT_SUITES);
  const[openIds,setOpenIds]=useState<string[]>([]);
  const[activeTab,setActiveTab]=useState<string>("list");

  const openSuite=(id:string)=>{
    if(!openIds.includes(id))setOpenIds(p=>[...p,id]);
    setActiveTab(id);
  };
  const closeSuite=(id:string,e:React.MouseEvent)=>{
    e.stopPropagation();
    const next=openIds.filter(x=>x!==id);
    setOpenIds(next);
    if(activeTab===id)setActiveTab(next[next.length-1]??"list");
  };
  const createSuite=()=>{
    const id=`new-${Date.now()}`;
    const newS:Suite={
      id,name:`未命名套件`,module:"全部",priority:"P2",
      status:"ACTIVE",desc:"",items:[],env:"测试环境",
      runMode:"serial",runLocation:"server",notify:false,
      lastRun:null,lastResult:null,
    };
    setSuites(p=>[...p,newS]);
    openSuite(id);
  };

  return(
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Multi-tab bar */}
      <div className="flex items-center flex-shrink-0 border-b px-2 gap-0" style={{height:38,borderColor:T.border,backgroundColor:"#fff"}}>
        <button onClick={()=>setActiveTab("list")}
          className="px-3 py-1 text-[12px] font-medium rounded-md mr-1 transition-colors flex-shrink-0"
          style={{backgroundColor:activeTab==="list"?"#E8F3FF":"transparent",color:activeTab==="list"?T.primary:T.t3}}>
          全部套件
        </button>
        <div className="w-px h-4 flex-shrink-0" style={{backgroundColor:T.border}}/>
        <div className="flex-1 flex items-center gap-0.5 overflow-x-auto px-1">
          {openIds.map(id=>{
            const s=suites.find(x=>x.id===id);
            const isActive=activeTab===id;
            return(
              <button key={id} onClick={()=>setActiveTab(id)}
                className="flex items-center gap-1.5 px-3 py-1 rounded-md text-[12px] font-medium whitespace-nowrap flex-shrink-0 transition-colors group/tab"
                style={{backgroundColor:isActive?"#E8F3FF":"transparent",color:isActive?T.primary:T.t3}}>
                <span className="max-w-[140px] truncate">{s?.name??"未命名套件"}</span>
                <span onClick={e=>closeSuite(id,e)}
                  className="w-4 h-4 flex items-center justify-center rounded hover:bg-blue-200/60 opacity-0 group-hover/tab:opacity-100 transition-opacity">
                  <X size={10}/>
                </span>
              </button>
            );
          })}
        </div>
        <button onClick={createSuite}
          className="w-7 h-7 flex-shrink-0 flex items-center justify-center rounded-md hover:bg-gray-100">
          <Plus size={14} style={{color:T.t3}}/>
        </button>
      </div>
      {/* Content */}
      {activeTab==="list"&&<SuiteListPage suites={suites} onOpen={openSuite} onCreate={createSuite}/>}
      {openIds.map(id=>(
        activeTab===id&&(
          <SuiteEditor key={id}
            suite={suites.find(s=>s.id===id)!}
            onChange={updated=>setSuites(p=>p.map(s=>s.id===id?updated:s))}/>
        )
      ))}
    </div>
  );
}
